﻿Public Class clsPerson
    'Member or trainer
    Public PersonType As String
   
End Class
