﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class TrainerCommission
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.LblID = New System.Windows.Forms.Label()
        Me.LblSurname = New System.Windows.Forms.Label()
        Me.lblName = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.LblClass = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.LblSalary = New System.Windows.Forms.Label()
        Me.LblTrainees = New System.Windows.Forms.Label()
        Me.LblTotal = New System.Windows.Forms.Label()
        Me.LblCommission = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.TxtSearch = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.BtnCalculate = New System.Windows.Forms.Button()
        Me.BtnSearch = New System.Windows.Forms.Button()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(6, 163)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(102, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Number Of Trainees"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(6, 22)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(54, 13)
        Me.Label3.TabIndex = 0
        Me.Label3.Text = "Trainer ID"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(6, 53)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(35, 13)
        Me.Label4.TabIndex = 1
        Me.Label4.Text = "Name"
        '
        'LblID
        '
        Me.LblID.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.LblID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.LblID.Location = New System.Drawing.Point(116, 21)
        Me.LblID.Name = "LblID"
        Me.LblID.Size = New System.Drawing.Size(102, 20)
        Me.LblID.TabIndex = 2
        '
        'LblSurname
        '
        Me.LblSurname.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.LblSurname.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.LblSurname.Location = New System.Drawing.Point(115, 81)
        Me.LblSurname.Name = "LblSurname"
        Me.LblSurname.Size = New System.Drawing.Size(102, 20)
        Me.LblSurname.TabIndex = 2
        '
        'lblName
        '
        Me.lblName.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.lblName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblName.Location = New System.Drawing.Point(116, 52)
        Me.lblName.Name = "lblName"
        Me.lblName.Size = New System.Drawing.Size(102, 20)
        Me.lblName.TabIndex = 2
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Label10)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.LblClass)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.lblName)
        Me.GroupBox1.Controls.Add(Me.Label7)
        Me.GroupBox1.Controls.Add(Me.LblSalary)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.LblTrainees)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.LblSurname)
        Me.GroupBox1.Controls.Add(Me.LblID)
        Me.GroupBox1.Location = New System.Drawing.Point(12, 98)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(248, 195)
        Me.GroupBox1.TabIndex = 3
        Me.GroupBox1.TabStop = False
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(6, 109)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(32, 13)
        Me.Label6.TabIndex = 3
        Me.Label6.Text = "Class"
        '
        'LblClass
        '
        Me.LblClass.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.LblClass.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.LblClass.Location = New System.Drawing.Point(115, 108)
        Me.LblClass.Name = "LblClass"
        Me.LblClass.Size = New System.Drawing.Size(102, 20)
        Me.LblClass.TabIndex = 4
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(6, 82)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(49, 13)
        Me.Label7.TabIndex = 0
        Me.Label7.Text = "Surname"
        '
        'LblSalary
        '
        Me.LblSalary.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.LblSalary.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.LblSalary.Location = New System.Drawing.Point(116, 135)
        Me.LblSalary.Name = "LblSalary"
        Me.LblSalary.Size = New System.Drawing.Size(102, 20)
        Me.LblSalary.TabIndex = 2
        '
        'LblTrainees
        '
        Me.LblTrainees.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.LblTrainees.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.LblTrainees.Location = New System.Drawing.Point(116, 162)
        Me.LblTrainees.Name = "LblTrainees"
        Me.LblTrainees.Size = New System.Drawing.Size(102, 20)
        Me.LblTrainees.TabIndex = 2
        '
        'LblTotal
        '
        Me.LblTotal.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.LblTotal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.LblTotal.Location = New System.Drawing.Point(128, 322)
        Me.LblTotal.Name = "LblTotal"
        Me.LblTotal.Size = New System.Drawing.Size(102, 20)
        Me.LblTotal.TabIndex = 7
        '
        'LblCommission
        '
        Me.LblCommission.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.LblCommission.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.LblCommission.Location = New System.Drawing.Point(128, 296)
        Me.LblCommission.Name = "LblCommission"
        Me.LblCommission.Size = New System.Drawing.Size(102, 20)
        Me.LblCommission.TabIndex = 8
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(18, 323)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(63, 13)
        Me.Label5.TabIndex = 5
        Me.Label5.Text = "Total Salary"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(18, 297)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(62, 13)
        Me.Label2.TabIndex = 6
        Me.Label2.Text = "Commission"
        '
        'TxtSearch
        '
        Me.TxtSearch.Location = New System.Drawing.Point(127, 68)
        Me.TxtSearch.Name = "TxtSearch"
        Me.TxtSearch.Size = New System.Drawing.Size(90, 20)
        Me.TxtSearch.TabIndex = 9
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(12, 71)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(104, 13)
        Me.Label8.TabIndex = 10
        Me.Label8.Text = "Search EmployeeNo"
        '
        'BtnCalculate
        '
        Me.BtnCalculate.Enabled = False
        Me.BtnCalculate.Location = New System.Drawing.Point(12, 355)
        Me.BtnCalculate.Name = "BtnCalculate"
        Me.BtnCalculate.Size = New System.Drawing.Size(75, 23)
        Me.BtnCalculate.TabIndex = 11
        Me.BtnCalculate.Text = "Calculate"
        Me.BtnCalculate.UseVisualStyleBackColor = True
        '
        'BtnSearch
        '
        Me.BtnSearch.Image = Global.BetaApp.My.Resources.Resources.magnify_alt__2_
        Me.BtnSearch.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.BtnSearch.Location = New System.Drawing.Point(237, 56)
        Me.BtnSearch.Name = "BtnSearch"
        Me.BtnSearch.Size = New System.Drawing.Size(35, 37)
        Me.BtnSearch.TabIndex = 12
        Me.BtnSearch.UseVisualStyleBackColor = True
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Century Gothic", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(8, 22)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(316, 22)
        Me.Label9.TabIndex = 13
        Me.Label9.Text = "- -Calcluate Trainers Commission- -"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(6, 136)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(36, 13)
        Me.Label10.TabIndex = 5
        Me.Label10.Text = "Salary"
        '
        'TrainerCommission
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(337, 390)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.BtnSearch)
        Me.Controls.Add(Me.BtnCalculate)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.TxtSearch)
        Me.Controls.Add(Me.LblTotal)
        Me.Controls.Add(Me.LblCommission)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "TrainerCommission"
        Me.Text = "TrainerCommission"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents LblID As System.Windows.Forms.Label
    Friend WithEvents LblSurname As System.Windows.Forms.Label
    Friend WithEvents lblName As System.Windows.Forms.Label
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents LblTrainees As System.Windows.Forms.Label
    Friend WithEvents LblTotal As System.Windows.Forms.Label
    Friend WithEvents LblCommission As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents TxtSearch As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents BtnCalculate As System.Windows.Forms.Button
    Friend WithEvents BtnSearch As System.Windows.Forms.Button
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents LblClass As System.Windows.Forms.Label
    Friend WithEvents LblSalary As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
End Class
