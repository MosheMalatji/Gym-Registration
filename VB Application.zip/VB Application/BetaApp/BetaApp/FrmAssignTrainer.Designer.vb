﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FrmAssignTrainer
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.LblName = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.LblMemType = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.LblSurname = New System.Windows.Forms.Label()
        Me.LblTrainerClass = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.LblID = New System.Windows.Forms.Label()
        Me.BtnFinish = New System.Windows.Forms.Button()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.dgvDisplay = New System.Windows.Forms.DataGridView()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.LblTrainerName = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.LblTrainerSurname = New System.Windows.Forms.Label()
        Me.LblEmpNo = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        CType(Me.dgvDisplay, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox3.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(18, 51)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(35, 13)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "Name"
        '
        'LblName
        '
        Me.LblName.BackColor = System.Drawing.SystemColors.Control
        Me.LblName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.LblName.Location = New System.Drawing.Point(108, 51)
        Me.LblName.Name = "LblName"
        Me.LblName.Size = New System.Drawing.Size(139, 21)
        Me.LblName.TabIndex = 3
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(18, 109)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(87, 13)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "Membership type"
        '
        'LblMemType
        '
        Me.LblMemType.BackColor = System.Drawing.SystemColors.Control
        Me.LblMemType.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.LblMemType.Location = New System.Drawing.Point(108, 108)
        Me.LblMemType.Name = "LblMemType"
        Me.LblMemType.Size = New System.Drawing.Size(139, 21)
        Me.LblMemType.TabIndex = 3
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(18, 81)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(49, 13)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "Surname"
        '
        'LblSurname
        '
        Me.LblSurname.BackColor = System.Drawing.SystemColors.Control
        Me.LblSurname.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.LblSurname.Location = New System.Drawing.Point(108, 80)
        Me.LblSurname.Name = "LblSurname"
        Me.LblSurname.Size = New System.Drawing.Size(139, 21)
        Me.LblSurname.TabIndex = 3
        '
        'LblTrainerClass
        '
        Me.LblTrainerClass.BackColor = System.Drawing.SystemColors.Control
        Me.LblTrainerClass.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.LblTrainerClass.Location = New System.Drawing.Point(108, 138)
        Me.LblTrainerClass.Name = "LblTrainerClass"
        Me.LblTrainerClass.Size = New System.Drawing.Size(139, 21)
        Me.LblTrainerClass.TabIndex = 5
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(18, 139)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(64, 13)
        Me.Label7.TabIndex = 4
        Me.Label7.Text = "Trainer Pool"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Label10)
        Me.GroupBox1.Controls.Add(Me.LblID)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.LblTrainerClass)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.Label7)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.LblSurname)
        Me.GroupBox1.Controls.Add(Me.LblName)
        Me.GroupBox1.Controls.Add(Me.LblMemType)
        Me.GroupBox1.Location = New System.Drawing.Point(3, 36)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(263, 169)
        Me.GroupBox1.TabIndex = 6
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Member Info"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(18, 16)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(58, 13)
        Me.Label10.TabIndex = 7
        Me.Label10.Text = "ID Number"
        '
        'LblID
        '
        Me.LblID.BackColor = System.Drawing.SystemColors.Control
        Me.LblID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.LblID.Location = New System.Drawing.Point(108, 16)
        Me.LblID.Name = "LblID"
        Me.LblID.Size = New System.Drawing.Size(139, 21)
        Me.LblID.TabIndex = 6
        '
        'BtnFinish
        '
        Me.BtnFinish.Location = New System.Drawing.Point(12, 548)
        Me.BtnFinish.Name = "BtnFinish"
        Me.BtnFinish.Size = New System.Drawing.Size(75, 23)
        Me.BtnFinish.TabIndex = 7
        Me.BtnFinish.Text = "&Done"
        Me.BtnFinish.UseVisualStyleBackColor = True
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Century Gothic", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(127, 9)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(169, 24)
        Me.Label9.TabIndex = 10
        Me.Label9.Text = "--Assign Trainer--"
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.dgvDisplay)
        Me.GroupBox2.Controls.Add(Me.Label12)
        Me.GroupBox2.Controls.Add(Me.GroupBox3)
        Me.GroupBox2.Location = New System.Drawing.Point(3, 211)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(439, 331)
        Me.GroupBox2.TabIndex = 11
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Pick A Trainer"
        '
        'dgvDisplay
        '
        Me.dgvDisplay.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvDisplay.Location = New System.Drawing.Point(6, 170)
        Me.dgvDisplay.Name = "dgvDisplay"
        Me.dgvDisplay.Size = New System.Drawing.Size(427, 150)
        Me.dgvDisplay.TabIndex = 13
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(6, 154)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(227, 13)
        Me.Label12.TabIndex = 12
        Me.Label12.Text = "DOUBLE CLICK ON ANY TRAINER BELOW :"
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.LblTrainerName)
        Me.GroupBox3.Controls.Add(Me.Label5)
        Me.GroupBox3.Controls.Add(Me.Label6)
        Me.GroupBox3.Controls.Add(Me.Label8)
        Me.GroupBox3.Controls.Add(Me.LblTrainerSurname)
        Me.GroupBox3.Controls.Add(Me.LblEmpNo)
        Me.GroupBox3.Controls.Add(Me.Label3)
        Me.GroupBox3.Location = New System.Drawing.Point(9, 19)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(420, 132)
        Me.GroupBox3.TabIndex = 11
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Trainer Info"
        '
        'LblTrainerName
        '
        Me.LblTrainerName.AutoSize = True
        Me.LblTrainerName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.LblTrainerName.Location = New System.Drawing.Point(108, 43)
        Me.LblTrainerName.Name = "LblTrainerName"
        Me.LblTrainerName.Size = New System.Drawing.Size(2, 15)
        Me.LblTrainerName.TabIndex = 10
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(18, 101)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(67, 13)
        Me.Label5.TabIndex = 7
        Me.Label5.Text = "EmployeeNo"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(18, 43)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(35, 13)
        Me.Label6.TabIndex = 8
        Me.Label6.Text = "Name"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(18, 73)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(49, 13)
        Me.Label8.TabIndex = 9
        Me.Label8.Text = "Surname"
        '
        'LblTrainerSurname
        '
        Me.LblTrainerSurname.BackColor = System.Drawing.SystemColors.Control
        Me.LblTrainerSurname.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.LblTrainerSurname.Location = New System.Drawing.Point(108, 72)
        Me.LblTrainerSurname.Name = "LblTrainerSurname"
        Me.LblTrainerSurname.Size = New System.Drawing.Size(139, 21)
        Me.LblTrainerSurname.TabIndex = 4
        '
        'LblEmpNo
        '
        Me.LblEmpNo.BackColor = System.Drawing.SystemColors.Control
        Me.LblEmpNo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.LblEmpNo.Location = New System.Drawing.Point(108, 100)
        Me.LblEmpNo.Name = "LblEmpNo"
        Me.LblEmpNo.Size = New System.Drawing.Size(139, 21)
        Me.LblEmpNo.TabIndex = 6
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(18, 16)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(164, 13)
        Me.Label3.TabIndex = 0
        Me.Label3.Text = "The trainer you have selected is :"
        '
        'FrmAssignTrainer
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(445, 583)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.BtnFinish)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "FrmAssignTrainer"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Genesis - Assigning trainer to new member"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        CType(Me.dgvDisplay, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents LblName As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents LblMemType As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents LblSurname As System.Windows.Forms.Label
    Friend WithEvents LblTrainerClass As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents BtnFinish As System.Windows.Forms.Button
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents LblTrainerSurname As System.Windows.Forms.Label
    Friend WithEvents LblEmpNo As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents LblID As System.Windows.Forms.Label
    Friend WithEvents dgvDisplay As System.Windows.Forms.DataGridView
    Friend WithEvents LblTrainerName As System.Windows.Forms.Label
End Class
