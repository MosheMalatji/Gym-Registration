﻿Imports System.Data.OleDb
Public Class FrmAssignTrainer

    Private Sub FrmAssignTrainer_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Call AddGymMember.ShowTrainerPool()
        Call populateTable()
    End Sub
    Sub populateTable()
        Try
            Dim command As New OleDb.OleDbCommand
            Dim connect As New OleDb.OleDbConnection
            Dim table As New Data.DataTable

            ' Set the ConnectionString property of the connection and open the database connection.
            connect.ConnectionString = "Provider=Microsoft.jet.Oledb.4.0; data source =C:\Users\Moshe\Documents\CP ISAT\Genisis\Database\GenisisFitnessClub.mdb"
            connect.Open()

            ' Set the Connection and CommandText properties of the command object.
            command.Connection = connect
            command.CommandText = "SELECT EmployeeNo,Name,Surname,Class FROM [Trainers] WHERE [Class]='" & LblTrainerClass.Text & "' AND [Class] = '" & LblTrainerClass.Text & "'"

            ' Execute the command and load the result set into the table.
            table.Load(command.ExecuteReader())

            ' Close the database connection.
            connect.Close()

            ' Set the table as DataSource for the grvSubjects DataGridView control.
            DgvDisplay.DataSource = table
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Sub SaveRelationship()
        Dim connect As New OleDb.OleDbConnection
        Dim command As New OleDb.OleDbCommand
        Dim Para1 As OleDb.OleDbParameter
        Dim Para2 As OleDb.OleDbParameter
        Dim Para3 As OleDb.OleDbParameter
        Dim Para4 As OleDb.OleDbParameter
        Dim Para5 As OleDb.OleDbParameter
        Dim Para6 As OleDb.OleDbParameter
        Try
            connect.ConnectionString = "Provider=Microsoft.jet.Oledb.4.0; data source =E:\CP ISAT\Genisis\Database\GenisisFitnessClub.mdb"
            connect.Open()

            command.Connection = connect
            command.CommandText = "INSERT INTO Trainer_Trainee(TrainerID,Trainer_Class,Member_ID,Trainee_Name,Trainee_Surname,Trainee_MembershipType) VALUES (@TrainerId,@Class,@MemberID,@TraineeName,@TraineeSurname,@MemType) "

            Para1 = New OleDb.OleDbParameter("@TrainerId", LblEmpNo.Text)
            Para2 = New OleDb.OleDbParameter("@Class", LblTrainerClass.Text)
            Para6 = New OleDb.OleDbParameter("@MemberID", LblID.Text)
            Para3 = New OleDb.OleDbParameter("@TraineeName", LblName.Text)
            Para4 = New OleDb.OleDbParameter("@TraineeSurname", LblSurname.Text)
            Para5 = New OleDb.OleDbParameter("@MemType", LblMemType.Text)

            command.Parameters.Add(Para1)
            command.Parameters.Add(Para2)
            command.Parameters.Add(Para6)
            command.Parameters.Add(Para3)
            command.Parameters.Add(Para4)
            command.Parameters.Add(Para5)
            command.ExecuteNonQuery()
            connect.Close()
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub BtnFinish_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnFinish.Click
        Call SaveRelationship()
        MessageBox.Show("Done")
        Me.Dispose()
    End Sub

    Private Sub dgvDisplay_CellDoubleClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles dgvDisplay.CellDoubleClick
        Dim i As Integer
        i = dgvDisplay.CurrentRow.Index
        LblTrainerName.Text = dgvDisplay.Item(1, i).Value
        LblTrainerSurname.Text = dgvDisplay.Item(2, i).Value
        LblEmpNo.Text = dgvDisplay.Item(0, i).Value
    End Sub

End Class