﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class AddGymMember
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.BtnSave = New System.Windows.Forms.Button()
        Me.BtnExit = New System.Windows.Forms.Button()
        Me.BtnClear = New System.Windows.Forms.Button()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.RadFemale = New System.Windows.Forms.RadioButton()
        Me.RadMale = New System.Windows.Forms.RadioButton()
        Me.LblAge = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.DtpDOB = New System.Windows.Forms.DateTimePicker()
        Me.TxtIDNumber = New System.Windows.Forms.TextBox()
        Me.TxtContactNo = New System.Windows.Forms.TextBox()
        Me.TxtSurname = New System.Windows.Forms.TextBox()
        Me.TxtName = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.BtnSubmit = New System.Windows.Forms.Button()
        Me.DtpDateJoined = New System.Windows.Forms.DateTimePicker()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.cmbMembershipType = New System.Windows.Forms.ComboBox()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.LblBMI = New System.Windows.Forms.Label()
        Me.LblHRmax = New System.Windows.Forms.Label()
        Me.LblVo2max = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.TxtHRrest = New System.Windows.Forms.TextBox()
        Me.Txtweight = New System.Windows.Forms.TextBox()
        Me.TxtHeight = New System.Windows.Forms.TextBox()
        Me.lblFee = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.TtpInfo = New System.Windows.Forms.ToolTip(Me.components)
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.SuspendLayout()
        '
        'BtnSave
        '
        Me.BtnSave.Enabled = False
        Me.BtnSave.Location = New System.Drawing.Point(12, 434)
        Me.BtnSave.Name = "BtnSave"
        Me.BtnSave.Size = New System.Drawing.Size(75, 23)
        Me.BtnSave.TabIndex = 13
        Me.BtnSave.Text = "&Next"
        Me.BtnSave.UseVisualStyleBackColor = True
        '
        'BtnExit
        '
        Me.BtnExit.Location = New System.Drawing.Point(441, 434)
        Me.BtnExit.Name = "BtnExit"
        Me.BtnExit.Size = New System.Drawing.Size(75, 23)
        Me.BtnExit.TabIndex = 12
        Me.BtnExit.Text = "E&xit"
        Me.BtnExit.UseVisualStyleBackColor = True
        '
        'BtnClear
        '
        Me.BtnClear.Location = New System.Drawing.Point(360, 434)
        Me.BtnClear.Name = "BtnClear"
        Me.BtnClear.Size = New System.Drawing.Size(75, 23)
        Me.BtnClear.TabIndex = 11
        Me.BtnClear.Text = "&Clear"
        Me.BtnClear.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.RadFemale)
        Me.GroupBox1.Controls.Add(Me.RadMale)
        Me.GroupBox1.Controls.Add(Me.LblAge)
        Me.GroupBox1.Controls.Add(Me.Label7)
        Me.GroupBox1.Controls.Add(Me.Label10)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.DtpDOB)
        Me.GroupBox1.Controls.Add(Me.TxtIDNumber)
        Me.GroupBox1.Controls.Add(Me.TxtContactNo)
        Me.GroupBox1.Controls.Add(Me.TxtSurname)
        Me.GroupBox1.Controls.Add(Me.TxtName)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Font = New System.Drawing.Font("Century Gothic", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.Location = New System.Drawing.Point(12, 36)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(506, 154)
        Me.GroupBox1.TabIndex = 10
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Personal Details"
        '
        'RadFemale
        '
        Me.RadFemale.AutoSize = True
        Me.RadFemale.Location = New System.Drawing.Point(152, 126)
        Me.RadFemale.Name = "RadFemale"
        Me.RadFemale.Size = New System.Drawing.Size(65, 20)
        Me.RadFemale.TabIndex = 18
        Me.RadFemale.TabStop = True
        Me.RadFemale.Text = "Female"
        Me.RadFemale.UseVisualStyleBackColor = True
        '
        'RadMale
        '
        Me.RadMale.AutoSize = True
        Me.RadMale.Location = New System.Drawing.Point(89, 126)
        Me.RadMale.Name = "RadMale"
        Me.RadMale.Size = New System.Drawing.Size(54, 20)
        Me.RadMale.TabIndex = 18
        Me.RadMale.TabStop = True
        Me.RadMale.Text = "Male"
        Me.RadMale.UseVisualStyleBackColor = True
        '
        'LblAge
        '
        Me.LblAge.BackColor = System.Drawing.SystemColors.ControlLightLight
        Me.LblAge.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.LblAge.Location = New System.Drawing.Point(330, 94)
        Me.LblAge.Name = "LblAge"
        Me.LblAge.Size = New System.Drawing.Size(75, 23)
        Me.LblAge.TabIndex = 17
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(252, 95)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(77, 16)
        Me.Label7.TabIndex = 16
        Me.Label7.Text = "Age               :"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Century Gothic", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(4, 126)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(80, 16)
        Me.Label10.TabIndex = 15
        Me.Label10.Text = "Gender         :"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Century Gothic", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(2, 101)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(79, 16)
        Me.Label6.TabIndex = 15
        Me.Label6.Text = "Date of Birth :"
        '
        'DtpDOB
        '
        Me.DtpDOB.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.DtpDOB.Location = New System.Drawing.Point(87, 97)
        Me.DtpDOB.MinDate = New Date(1920, 1, 1, 0, 0, 0, 0)
        Me.DtpDOB.Name = "DtpDOB"
        Me.DtpDOB.Size = New System.Drawing.Size(153, 21)
        Me.DtpDOB.TabIndex = 14
        Me.DtpDOB.Value = New Date(2016, 8, 10, 0, 0, 0, 0)
        '
        'TxtIDNumber
        '
        Me.TxtIDNumber.Location = New System.Drawing.Point(87, 23)
        Me.TxtIDNumber.Name = "TxtIDNumber"
        Me.TxtIDNumber.Size = New System.Drawing.Size(153, 21)
        Me.TxtIDNumber.TabIndex = 2
        '
        'TxtContactNo
        '
        Me.TxtContactNo.Location = New System.Drawing.Point(327, 23)
        Me.TxtContactNo.Name = "TxtContactNo"
        Me.TxtContactNo.Size = New System.Drawing.Size(153, 21)
        Me.TxtContactNo.TabIndex = 2
        '
        'TxtSurname
        '
        Me.TxtSurname.Location = New System.Drawing.Point(330, 58)
        Me.TxtSurname.Name = "TxtSurname"
        Me.TxtSurname.Size = New System.Drawing.Size(153, 21)
        Me.TxtSurname.TabIndex = 2
        '
        'TxtName
        '
        Me.TxtName.Location = New System.Drawing.Point(87, 61)
        Me.TxtName.Name = "TxtName"
        Me.TxtName.Size = New System.Drawing.Size(153, 21)
        Me.TxtName.TabIndex = 2
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Century Gothic", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(249, 26)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(81, 16)
        Me.Label4.TabIndex = 1
        Me.Label4.Text = "Contact No  :"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Century Gothic", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(252, 61)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(77, 16)
        Me.Label3.TabIndex = 1
        Me.Label3.Text = "Surname      :"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Century Gothic", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(2, 66)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(77, 16)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Name           :"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Century Gothic", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(2, 26)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(77, 16)
        Me.Label5.TabIndex = 1
        Me.Label5.Text = "ID Number   :"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Century Gothic", 15.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(158, 9)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(196, 24)
        Me.Label1.TabIndex = 8
        Me.Label1.Text = "--Add A Member--"
        '
        'BtnSubmit
        '
        Me.BtnSubmit.Location = New System.Drawing.Point(399, 133)
        Me.BtnSubmit.Name = "BtnSubmit"
        Me.BtnSubmit.Size = New System.Drawing.Size(75, 23)
        Me.BtnSubmit.TabIndex = 13
        Me.BtnSubmit.Text = "&Submit"
        Me.BtnSubmit.UseVisualStyleBackColor = True
        '
        'DtpDateJoined
        '
        Me.DtpDateJoined.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.DtpDateJoined.Location = New System.Drawing.Point(7, 34)
        Me.DtpDateJoined.MinDate = New Date(2000, 1, 1, 0, 0, 0, 0)
        Me.DtpDateJoined.Name = "DtpDateJoined"
        Me.DtpDateJoined.Size = New System.Drawing.Size(153, 20)
        Me.DtpDateJoined.TabIndex = 14
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.cmbMembershipType)
        Me.GroupBox2.Controls.Add(Me.GroupBox3)
        Me.GroupBox2.Controls.Add(Me.lblFee)
        Me.GroupBox2.Controls.Add(Me.Label17)
        Me.GroupBox2.Controls.Add(Me.Label9)
        Me.GroupBox2.Controls.Add(Me.Label8)
        Me.GroupBox2.Controls.Add(Me.DtpDateJoined)
        Me.GroupBox2.Location = New System.Drawing.Point(12, 196)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(506, 228)
        Me.GroupBox2.TabIndex = 15
        Me.GroupBox2.TabStop = False
        '
        'cmbMembershipType
        '
        Me.cmbMembershipType.FormattingEnabled = True
        Me.cmbMembershipType.Location = New System.Drawing.Point(221, 33)
        Me.cmbMembershipType.Name = "cmbMembershipType"
        Me.cmbMembershipType.Size = New System.Drawing.Size(130, 21)
        Me.cmbMembershipType.TabIndex = 17
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.LblBMI)
        Me.GroupBox3.Controls.Add(Me.BtnSubmit)
        Me.GroupBox3.Controls.Add(Me.LblHRmax)
        Me.GroupBox3.Controls.Add(Me.LblVo2max)
        Me.GroupBox3.Controls.Add(Me.Label14)
        Me.GroupBox3.Controls.Add(Me.Label16)
        Me.GroupBox3.Controls.Add(Me.Label15)
        Me.GroupBox3.Controls.Add(Me.Label13)
        Me.GroupBox3.Controls.Add(Me.Label12)
        Me.GroupBox3.Controls.Add(Me.Label11)
        Me.GroupBox3.Controls.Add(Me.TxtHRrest)
        Me.GroupBox3.Controls.Add(Me.Txtweight)
        Me.GroupBox3.Controls.Add(Me.TxtHeight)
        Me.GroupBox3.Location = New System.Drawing.Point(6, 58)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(494, 162)
        Me.GroupBox3.TabIndex = 0
        Me.GroupBox3.TabStop = False
        '
        'LblBMI
        '
        Me.LblBMI.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.LblBMI.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.LblBMI.Location = New System.Drawing.Point(80, 106)
        Me.LblBMI.Name = "LblBMI"
        Me.LblBMI.Size = New System.Drawing.Size(400, 21)
        Me.LblBMI.TabIndex = 3
        '
        'LblHRmax
        '
        Me.LblHRmax.BackColor = System.Drawing.SystemColors.Control
        Me.LblHRmax.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.LblHRmax.Font = New System.Drawing.Font("Century Gothic", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LblHRmax.Location = New System.Drawing.Point(329, 46)
        Me.LblHRmax.Name = "LblHRmax"
        Me.LblHRmax.Size = New System.Drawing.Size(151, 20)
        Me.LblHRmax.TabIndex = 15
        '
        'LblVo2max
        '
        Me.LblVo2max.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.LblVo2max.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.LblVo2max.Location = New System.Drawing.Point(80, 73)
        Me.LblVo2max.Name = "LblVo2max"
        Me.LblVo2max.Size = New System.Drawing.Size(400, 21)
        Me.LblVo2max.TabIndex = 3
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Century Gothic", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.Location = New System.Drawing.Point(245, 15)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(77, 16)
        Me.Label14.TabIndex = 1
        Me.Label14.Text = "HRrest           :"
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Font = New System.Drawing.Font("Century Gothic", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.Location = New System.Drawing.Point(11, 111)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(67, 16)
        Me.Label16.TabIndex = 1
        Me.Label16.Text = "BMI            :"
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Century Gothic", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.Location = New System.Drawing.Point(6, 78)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(73, 16)
        Me.Label15.TabIndex = 1
        Me.Label15.Text = "VO2max     :"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Century Gothic", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(246, 48)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(77, 16)
        Me.Label13.TabIndex = 1
        Me.Label13.Text = "HRmax         :"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Century Gothic", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(6, 48)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(72, 16)
        Me.Label12.TabIndex = 1
        Me.Label12.Text = "Weight(kg) :"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Century Gothic", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(6, 16)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(74, 16)
        Me.Label11.TabIndex = 1
        Me.Label11.Text = "Height (cm):"
        '
        'TxtHRrest
        '
        Me.TxtHRrest.Location = New System.Drawing.Point(328, 13)
        Me.TxtHRrest.Name = "TxtHRrest"
        Me.TxtHRrest.Size = New System.Drawing.Size(153, 20)
        Me.TxtHRrest.TabIndex = 2
        '
        'Txtweight
        '
        Me.Txtweight.Location = New System.Drawing.Point(80, 46)
        Me.Txtweight.Name = "Txtweight"
        Me.Txtweight.Size = New System.Drawing.Size(153, 20)
        Me.Txtweight.TabIndex = 2
        '
        'TxtHeight
        '
        Me.TxtHeight.Location = New System.Drawing.Point(80, 13)
        Me.TxtHeight.Name = "TxtHeight"
        Me.TxtHeight.Size = New System.Drawing.Size(153, 20)
        Me.TxtHeight.TabIndex = 2
        '
        'lblFee
        '
        Me.lblFee.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.lblFee.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblFee.Font = New System.Drawing.Font("Century Gothic", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblFee.Location = New System.Drawing.Point(376, 34)
        Me.lblFee.Name = "lblFee"
        Me.lblFee.Size = New System.Drawing.Size(111, 20)
        Me.lblFee.TabIndex = 15
        '
        'Label17
        '
        Me.Label17.AutoSize = True
        Me.Label17.Font = New System.Drawing.Font("Century Gothic", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.Location = New System.Drawing.Point(373, 14)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(97, 16)
        Me.Label17.TabIndex = 15
        Me.Label17.Text = "Membership Fee"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Century Gothic", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(218, 14)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(104, 16)
        Me.Label9.TabIndex = 15
        Me.Label9.Text = "Membership Type"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Century Gothic", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(4, 14)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(59, 16)
        Me.Label8.TabIndex = 15
        Me.Label8.Text = "Join Date"
        '
        'AddGymMember
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(534, 468)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.BtnSave)
        Me.Controls.Add(Me.BtnExit)
        Me.Controls.Add(Me.BtnClear)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.Label1)
        Me.Name = "AddGymMember"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Genesis - Add a new gym member"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents BtnSave As System.Windows.Forms.Button
    Friend WithEvents BtnExit As System.Windows.Forms.Button
    Friend WithEvents BtnClear As System.Windows.Forms.Button
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents TxtSurname As System.Windows.Forms.TextBox
    Friend WithEvents TxtName As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents TxtIDNumber As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents BtnSubmit As System.Windows.Forms.Button
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents DtpDOB As System.Windows.Forms.DateTimePicker
    Friend WithEvents LblAge As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents DtpDateJoined As System.Windows.Forms.DateTimePicker
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents cmbMembershipType As System.Windows.Forms.ComboBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents RadFemale As System.Windows.Forms.RadioButton
    Friend WithEvents RadMale As System.Windows.Forms.RadioButton
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents LblVo2max As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents TxtHRrest As System.Windows.Forms.TextBox
    Friend WithEvents Txtweight As System.Windows.Forms.TextBox
    Friend WithEvents TxtHeight As System.Windows.Forms.TextBox
    Friend WithEvents LblBMI As System.Windows.Forms.Label
    Friend WithEvents TtpInfo As System.Windows.Forms.ToolTip
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents lblFee As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents LblHRmax As System.Windows.Forms.Label
    Friend WithEvents TxtContactNo As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
End Class
