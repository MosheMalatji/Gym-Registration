﻿Public Class SearchMember
    Sub GetPhysicalInfo()
        Try
            ' Declare the connection, command and table objects.
            Dim connection As New OleDb.OleDbConnection
            Dim command As New OleDb.OleDbCommand
            Dim table As New Data.DataTable
            ' Set the ConnectionString property and open the database connection.
            connection.ConnectionString = "Provider=Microsoft.jet.Oledb.4.0; data source =C:\Users\Moshe\Documents\CP ISAT\Genisis\Database\GenisisFitnessClub.mdb"
            ' Set the Connection and CommandText properties of the command.
            command.Connection = connection
            'open Db
            connection.Open()
            'SQL query to look for Trainer
            command.CommandText = "SELECT * FROM Member_Physical WHERE Member_ID = @IDNumber"

            ' Declare and initialize the parameter required by the command.
            Dim parID = New OleDb.OleDbParameter("@IDNumber", txtSearch.Text)

            ' Add the parameter to the command.
            command.Parameters.Add(parID)

            ' Execute the command and load the result set into the table.
            table.Load(command.ExecuteReader())

            ' Close the database connection.
            connection.Close()

            If table.Rows.Count > 0 Then ' Check whether there was any results in the result set and load the result set's data into the input controls.
                TxtHeight.Text = table.Rows(0)("Height").ToString()
                TxtWeight.Text = table.Rows(0)("Weight").ToString()
                TxtHRrest.Text = table.Rows(0)("HRrest").ToString()
                TxtHRmax.Text = table.Rows(0)("HRmax").ToString()
                TxtVo2max.Text = table.Rows(0)("VO2max").ToString()
                TxtBmi.Text = table.Rows(0)("VO2max").ToString()

            Else ' Else prompt the user that no student was found and make all the display fields blank.
                TxtHeight.Text = ""
                TxtWeight.Text = ""
                TxtHRrest.Text = ""
                TxtHRmax.Text = ""
                TxtVo2max.Text = ""
                TxtBmi.Text = ""

                MessageBox.Show("Member not found, please try again.")
            End If
        Catch ex As Exception
            ' Prompt the user with the exception.
            MessageBox.Show(ex.ToString())
        End Try
    End Sub

    Sub GetPersonalInfo()
        Try
            ' Declare the connection, command and table objects.
            Dim connection As New OleDb.OleDbConnection
            Dim command As New OleDb.OleDbCommand
            Dim table As New Data.DataTable
            ' Set the ConnectionString property and open the database connection.
            connection.ConnectionString = "Provider=Microsoft.jet.Oledb.4.0; data source =E:\CP ISAT\Genisis\Database\GenisisFitnessClub.mdb"
            ' Set the Connection and CommandText properties of the command.
            command.Connection = connection
            'open Db
            connection.Open()
            'SQL query to look for Trainer
            command.CommandText = "SELECT * FROM Member_Personal WHERE Member_ID = @IDNumber"

            ' Declare and initialize the parameter required by the command.
            Dim parID = New OleDb.OleDbParameter("@IDNumber", txtSearch.Text)

            ' Add the parameter to the command.
            command.Parameters.Add(parID)

            ' Execute the command and load the result set into the table.
            table.Load(command.ExecuteReader())

            ' Close the database connection.
            connection.Close()
            ' Check whether there was any results in the result set and load the result set's data into the input controls.
            If table.Rows.Count > 0 Then
                TxtID.Text = table.Rows(0)("IDNumber").ToString()
                txtName.Text = table.Rows(0)("Member_Name").ToString()
                txtSurname.Text = table.Rows(0)("Member_Surname").ToString()
                TxtDOB.Text = table.Rows(0)("Date_Of_Birth").ToString()
                TxtGender.Text = table.Rows(0)("Gender").ToString()
                txtJoinDate.Text = table.Rows(0)("Join_Date").ToString()
                TxtMemType.Text = table.Rows(0)("Membership_Type").ToString()
                TxtMemFee.Text = table.Rows(0)("Membership_Fee").ToString()
                ' Else prompt the user that no gym member was found and make all the display fields blank.
            Else
              
                ' Else prompt the user that no gym member was found and make all the display fields blank.
                TxtID.Text = ""
                txtName.Text = ""
                txtSurname.Text = ""
                TxtDOB.Text = ""
                TxtGender.Text = ""
                txtJoinDate.Text = ""
                TxtMemType.Text = ""
                TxtMemFee.Text = ""
                MessageBox.Show("Member not found, please try again.")
            End If
        Catch ex As Exception
            ' Prompt the user with the exception.
            MessageBox.Show(ex.ToString())
        End Try
    End Sub
    Private Sub BtnSearch_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnSearch.Click
        Call GetPhysicalInfo()
    End Sub
End Class