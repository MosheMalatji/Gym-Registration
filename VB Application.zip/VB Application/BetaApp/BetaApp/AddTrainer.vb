﻿Imports System.Data.OleDb

Public Class AddTrainer
    'Declare object
    Dim trainer As clsTrainer
    'Button verifies data and enables save button if data is valid
    Private Sub BtnSubmit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnSubmit.Click
        'Declare variable(s) for function
        Dim DateJoined As Integer
        Dim msg As String = " "
        trainer = New clsTrainer(TxtName.Text, TxtSurname.Text, TxtContactNo.Text, DtpHired.Value, lblEmployeeNumber.Text)



        'If function is false then store show confirmation msg box
        If checkDetails(msg) = False Then
            MessageBox.Show(msg, "Invalid", MessageBoxButtons.OK, MessageBoxIcon.Information)
        Else
            'Else show display salary,class, employee Number and enable save button
            Call SetSalaryAndClass(DateJoined)
            lblEmployeeNumber.Text = GenerateEmployeeNo()
            MessageBox.Show(msg, "Valid", MessageBoxButtons.OK, MessageBoxIcon.Information)
            BtnSave.Enabled = True
        End If
    End Sub
    'This function determines Trainers Class + salary based on date trainer was hired on
    
    'close and dispose content
    Private Sub BtnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnExit.Click
        'me.dispose clears all the controls when exit button is clicked
        Me.Dispose()
    End Sub
    'Sub procedure to clear all controls
    Public Sub clearcontrols()
        TxtName.Clear()
        TxtSurname.Clear()
        TxtContactNo.Clear()
        DtpHired.Value = Today.Date
        LblClass.Text = " "
        LblSalary.Text = " "
        lblEmployeeNumber.Text = " "
        BtnSave.Enabled = False
    End Sub
    'Function to valdidate details
    Function checkDetails(ByRef returnmsg As String) As Boolean
        'Declare variables
        Dim Validty As Boolean = False
        If String.IsNullOrWhiteSpace(TxtName.Text) Then
            returnmsg = "Please fill in Name"
            TxtName.Focus()
        ElseIf IsNumeric(TxtName.Text) Then
            returnmsg = "Name must be text only. The first letter must be a capital letter"
            TxtName.Focus()
        ElseIf String.IsNullOrEmpty(TxtSurname.Text) Then
            returnmsg = " Please fill in trainers surname"
            TxtSurname.Focus()
        ElseIf IsNumeric(TxtSurname.Text) Then
            returnmsg = "Surname must be text only. The first letter must be a capital letter"
            TxtSurname.Focus()
        ElseIf String.IsNullOrEmpty(TxtContactNo.Text) Then
            returnmsg = " Please fill in trainers contact no"
            TxtContactNo.Focus()
        ElseIf IsNumeric(TxtContactNo.Text) = False Then
            returnmsg = "Contact number must be numeric values only"
            TxtContactNo.Focus()
        ElseIf DtpHired.Value.Year > Today.Year Then
            returnmsg = " Trainer must be employed in 2016 or before not in the future "
            DtpHired.Focus()
        Else
            returnmsg = "Input valid. Please save before you quit."
            Validty = True
        End If

        'Return Boolean variable
        Return Validty
    End Function
    'Clear all controls by calling clearcontrols()
    Private Sub BtnClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnClear.Click
        Call clearcontrols()
    End Sub
    'Generate employee number
    Private Function GenerateEmployeeNo() As String

        trainer = New clsTrainer(TxtName.Text, TxtSurname.Text, TxtContactNo.Text, DtpHired.Value, lblEmployeeNumber.Text)
        trainer._Name = TxtName.Text
        trainer._Surname = TxtSurname.Text
        'Variable to store generated string
        Dim GenEmployeeNo As String = " "
        'fetch First letter from name and surname and use concat function to give initials
        Dim initials As String = String.Concat(trainer._Name.Substring(0, 1), trainer._Surname.Substring(0, 1))
        'generate a random value using built in random variable
        Dim RandomValue As Random = New Random()

        Try
            'Set random number to choose a random no between 1000 and 9 999 and concat said number with intitials
            GenEmployeeNo = String.Concat(initials, RandomValue.Next(1000, 10000).ToString())
            'return generated no
        Catch ex As Exception
            MessageBox.Show("Hey")
        End Try
        Return GenEmployeeNo
    End Function
    'Procedure that save all fields to database table
    Sub SaveToDb()
        Dim Command As New OleDb.OleDbCommand
        Dim Connect As New OleDb.OleDbConnection
        Dim Para1 As OleDb.OleDbParameter
        Dim Para2 As OleDb.OleDbParameter
        Dim Para3 As OleDb.OleDbParameter
        Dim Para4 As OleDb.OleDbParameter
        Dim Para5 As OleDb.OleDbParameter
        Dim Para6 As OleDb.OleDbParameter
        Dim Para7 As OleDb.OleDbParameter

        Call InstatiateObjects()

        Try
            Dim sql As String
            sql = "INSERT INTO Trainers(EmployeeNo,Name,Surname,Contact_No,DateJoined,Class,Salary) VALUES (@EmpNo,@Name,@Surname,@ContactNo,@DateHired,@Class,@Salary) "
            Connect.ConnectionString = "Provider=Microsoft.jet.Oledb.4.0; data source =E:\CP ISAT\Genisis\Database\GenisisFitnessClub.mdb"

            Command.Connection = Connect

            Connect.Open()

            Command.CommandText = sql

            Para1 = New OleDb.OleDbParameter("@EmpNo", lblEmployeeNumber.Text)
            Para2 = New OleDb.OleDbParameter("@Name", TxtName.Text)
            Para3 = New OleDb.OleDbParameter("@Surname", TxtSurname.Text)
            Para4 = New OleDb.OleDbParameter("@ContactNo", TxtContactNo.Text)
            Para5 = New OleDb.OleDbParameter("@Datehired", DtpHired.Text)
            Para6 = New OleDb.OleDbParameter("@class", LblClass.Text)
            Para7 = New OleDb.OleDbParameter("@salary", LblSalary.Text)

            Command.Parameters.Add(Para1)
            Command.Parameters.Add(Para2)
            Command.Parameters.Add(Para3)
            Command.Parameters.Add(Para4)
            Command.Parameters.Add(Para5)
            Command.Parameters.Add(Para6)
            Command.Parameters.Add(Para7)

            Command.ExecuteNonQuery()
            MessageBox.Show("trainer has been added")
            Connect.Close()
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub
    'Instantiate
    Sub InstatiateObjects()
        'Instantiate object
        trainer = New clsTrainer(TxtName.Text, TxtSurname.Text, TxtContactNo.Text, DtpHired.Value, lblEmployeeNumber.Text)
        'Set values for database parameters
        trainer._Name = TxtName.Text
        trainer._Surname = TxtSurname.Text
        trainer._ContactNo = TxtContactNo.Text
        trainer._DateHired = DtpHired.Value
        lblEmployeeNumber.Text = trainer._EmployeeNo
        'Instantiate object
        trainer = New clsTrainer(LblClass.Text, LblSalary.Text)
        'Set values for database parameters
        trainer._TrainerClass = LblClass.Text
        trainer._Salary = LblSalary.Text
    End Sub
    'Save
    Private Sub BtnSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnSave.Click
        Call SaveToDb()
    End Sub

    

    Public Function SetSalaryAndClass(ByVal DateHired As Integer)
        'I found that if the lblSalary.text = 0 is not set to 0 an error is returned due to "" being a string
        LblSalary.Text = 0
        'set parameter to an object(datetimepicker)
        DateHired = DtpHired.Value.Year

        trainer = New clsTrainer(LblClass.Text, LblSalary.Text)
        'Set values for database parameters
        trainer._TrainerClass = LblClass.Text
        trainer._Salary = LblSalary.Text

        If DateHired = Today.Year Or DateHired = Today.Year - 1 Then
            'if trainer joined in current year or a year ago assing lowest class and relevant salary
            trainer._Salary = 5000
            LblSalary.Text = trainer._Salary.ToString("c2")

            trainer._TrainerClass = "Class C"
            LblClass.Text = trainer._TrainerClass

        ElseIf DateHired = Today.Year - 2 Or DateHired = Today.Year - 3 Or DateHired = Today.Year - 4 Then
            'if trainer joined 2,3 or 4 years ago then assign class b
            trainer._Salary = 7500
            LblSalary.Text = trainer._Salary.ToString("c2")

            trainer._TrainerClass = "Class B"
            LblClass.Text = trainer._TrainerClass
        ElseIf DateHired <= Today.Year - 5 Then
            'if trainer joined 5 or more years ago then assign highest class
            trainer._Salary = 10000
            LblSalary.Text = trainer._Salary.ToString("c2")

            trainer._TrainerClass = "Class A"
            LblClass.Text = trainer._TrainerClass
        Else
            'do nothing
        End If

        Return DateHired
    End Function

    Private Sub AddTrainer_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'clear all controls for a new session
        Call clearcontrols()
    End Sub
End Class