﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MainMenu
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(MainMenu))
        Me.lbluser = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Lbltime = New System.Windows.Forms.Label()
        Me.LblDate = New System.Windows.Forms.Label()
        Me.LblVersion = New System.Windows.Forms.Label()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.ToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.AddTrainerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.EditTrainerInfoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ViewTrainersToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.AddMemeberToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.EditMemberToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.EditPersonalInfoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.EditPhysicalIndoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SearchMemberToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem3 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExitToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Panel1.SuspendLayout()
        Me.MenuStrip1.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lbluser
        '
        Me.lbluser.AutoSize = True
        Me.lbluser.Location = New System.Drawing.Point(3, 0)
        Me.lbluser.Name = "lbluser"
        Me.lbluser.Size = New System.Drawing.Size(0, 13)
        Me.lbluser.TabIndex = 1
        '
        'Panel1
        '
        Me.Panel1.AutoScroll = True
        Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel1.Controls.Add(Me.Lbltime)
        Me.Panel1.Controls.Add(Me.LblDate)
        Me.Panel1.Controls.Add(Me.LblVersion)
        Me.Panel1.Controls.Add(Me.lbluser)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel1.Location = New System.Drawing.Point(0, 359)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(831, 41)
        Me.Panel1.TabIndex = 3
        '
        'Lbltime
        '
        Me.Lbltime.AutoSize = True
        Me.Lbltime.Location = New System.Drawing.Point(3, 22)
        Me.Lbltime.Name = "Lbltime"
        Me.Lbltime.Size = New System.Drawing.Size(0, 13)
        Me.Lbltime.TabIndex = 2
        '
        'LblDate
        '
        Me.LblDate.AutoSize = True
        Me.LblDate.Location = New System.Drawing.Point(83, 22)
        Me.LblDate.Name = "LblDate"
        Me.LblDate.Size = New System.Drawing.Size(0, 13)
        Me.LblDate.TabIndex = 2
        '
        'LblVersion
        '
        Me.LblVersion.AutoSize = True
        Me.LblVersion.Dock = System.Windows.Forms.DockStyle.Right
        Me.LblVersion.Location = New System.Drawing.Point(829, 0)
        Me.LblVersion.Name = "LblVersion"
        Me.LblVersion.Size = New System.Drawing.Size(0, 13)
        Me.LblVersion.TabIndex = 1
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripMenuItem1, Me.ToolStripMenuItem2, Me.ToolStripMenuItem3, Me.ExitToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(831, 24)
        Me.MenuStrip1.TabIndex = 5
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'ToolStripMenuItem1
        '
        Me.ToolStripMenuItem1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AddTrainerToolStripMenuItem, Me.EditTrainerInfoToolStripMenuItem, Me.ViewTrainersToolStripMenuItem})
        Me.ToolStripMenuItem1.Name = "ToolStripMenuItem1"
        Me.ToolStripMenuItem1.Size = New System.Drawing.Size(63, 20)
        Me.ToolStripMenuItem1.Text = "&Trainers "
        '
        'AddTrainerToolStripMenuItem
        '
        Me.AddTrainerToolStripMenuItem.Name = "AddTrainerToolStripMenuItem"
        Me.AddTrainerToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.AddTrainerToolStripMenuItem.Text = "Add Trainer"
        '
        'EditTrainerInfoToolStripMenuItem
        '
        Me.EditTrainerInfoToolStripMenuItem.Name = "EditTrainerInfoToolStripMenuItem"
        Me.EditTrainerInfoToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.EditTrainerInfoToolStripMenuItem.Text = "Edit Trainer Info"
        '
        'ViewTrainersToolStripMenuItem
        '
        Me.ViewTrainersToolStripMenuItem.Name = "ViewTrainersToolStripMenuItem"
        Me.ViewTrainersToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.ViewTrainersToolStripMenuItem.Text = "Trainer Commission"
        '
        'ToolStripMenuItem2
        '
        Me.ToolStripMenuItem2.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AddMemeberToolStripMenuItem, Me.EditMemberToolStripMenuItem, Me.SearchMemberToolStripMenuItem})
        Me.ToolStripMenuItem2.Name = "ToolStripMenuItem2"
        Me.ToolStripMenuItem2.Size = New System.Drawing.Size(69, 20)
        Me.ToolStripMenuItem2.Text = "&Members"
        '
        'AddMemeberToolStripMenuItem
        '
        Me.AddMemeberToolStripMenuItem.Name = "AddMemeberToolStripMenuItem"
        Me.AddMemeberToolStripMenuItem.Size = New System.Drawing.Size(157, 22)
        Me.AddMemeberToolStripMenuItem.Text = "Add Member"
        '
        'EditMemberToolStripMenuItem
        '
        Me.EditMemberToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.EditPersonalInfoToolStripMenuItem, Me.EditPhysicalIndoToolStripMenuItem})
        Me.EditMemberToolStripMenuItem.Name = "EditMemberToolStripMenuItem"
        Me.EditMemberToolStripMenuItem.Size = New System.Drawing.Size(157, 22)
        Me.EditMemberToolStripMenuItem.Text = "Edit Member"
        '
        'EditPersonalInfoToolStripMenuItem
        '
        Me.EditPersonalInfoToolStripMenuItem.Name = "EditPersonalInfoToolStripMenuItem"
        Me.EditPersonalInfoToolStripMenuItem.Size = New System.Drawing.Size(167, 22)
        Me.EditPersonalInfoToolStripMenuItem.Text = "Edit Personal Info"
        '
        'EditPhysicalIndoToolStripMenuItem
        '
        Me.EditPhysicalIndoToolStripMenuItem.Name = "EditPhysicalIndoToolStripMenuItem"
        Me.EditPhysicalIndoToolStripMenuItem.Size = New System.Drawing.Size(167, 22)
        Me.EditPhysicalIndoToolStripMenuItem.Text = "Edit Physical Indo"
        '
        'SearchMemberToolStripMenuItem
        '
        Me.SearchMemberToolStripMenuItem.Name = "SearchMemberToolStripMenuItem"
        Me.SearchMemberToolStripMenuItem.Size = New System.Drawing.Size(157, 22)
        Me.SearchMemberToolStripMenuItem.Text = "Search Member"
        '
        'ToolStripMenuItem3
        '
        Me.ToolStripMenuItem3.Name = "ToolStripMenuItem3"
        Me.ToolStripMenuItem3.Size = New System.Drawing.Size(52, 20)
        Me.ToolStripMenuItem3.Text = "About"
        '
        'ExitToolStripMenuItem
        '
        Me.ExitToolStripMenuItem.Name = "ExitToolStripMenuItem"
        Me.ExitToolStripMenuItem.Size = New System.Drawing.Size(37, 20)
        Me.ExitToolStripMenuItem.Text = "E&xit"
        '
        'PictureBox1
        '
        Me.PictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.PictureBox1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(0, 24)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(831, 335)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 8
        Me.PictureBox1.TabStop = False
        '
        'MainMenu
        '
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Inherit
        Me.BackColor = System.Drawing.SystemColors.ButtonFace
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(831, 400)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.MenuStrip1)
        Me.IsMdiContainer = True
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "MainMenu"
        Me.Text = "Genisis - MainMenu"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lbluser As System.Windows.Forms.Label
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Lbltime As System.Windows.Forms.Label
    Friend WithEvents LblDate As System.Windows.Forms.Label
    Friend WithEvents LblVersion As System.Windows.Forms.Label
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents ToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AddTrainerToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EditTrainerInfoToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ViewTrainersToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents AddMemeberToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EditMemberToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SearchMemberToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ExitToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents ToolStripMenuItem3 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EditPersonalInfoToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EditPhysicalIndoToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
End Class
