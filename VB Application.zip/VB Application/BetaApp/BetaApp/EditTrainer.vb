﻿Public Class EditTrainer
    ' Declare the String variable to keep track of the function required(Update,Delete)
    Dim Mode As String

    Public Sub GetTrainers()
        Try
            ' Declare the connection, command and table objects.
            Dim connection As New OleDb.OleDbConnection
            Dim command As New OleDb.OleDbCommand
            Dim table As New Data.DataTable

            ' Initialize the ConnectionString and open the database connection.
            connection.ConnectionString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\Users\Moshe\Documents\CP ISAT\Genisis\Database\GenisisFitnessClub.mdb"
            connection.Open()

            ' Set the Connection and CommandText properties of the command.
            command.Connection = connection
            command.CommandText = "SELECT * FROM Trainers ORDER BY EmployeeNo"

            ' Execute the command and load the result set into the table.
            table.Load(command.ExecuteReader())

            ' Close the database connection.
            connection.Close()

            ' Set the table as the DataSource for the DataGridView.
            grvTrainers.DataSource = table
        Catch ex As Exception
            ' Prompt the user with the exception.
            MessageBox.Show(ex.ToString())
        End Try
    End Sub

    Private Sub GetTrainer(ByVal pID As Integer)
        Try
            ' Declare the connection, command and table objects.
            Dim connection As New OleDb.OleDbConnection
            Dim command As New OleDb.OleDbCommand
            Dim table As New Data.DataTable

            ' Set the ConnectionString property and open the database connection.
            connection.ConnectionString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=E:\CP ISAT\Genisis\Database\GenisisFitnessClub.mdb"
            connection.Open()

            ' Set the Connection and CommandText properties of the command.
            command.Connection = connection
            command.CommandText = "SELECT * FROM Trainers WHERE EmployeeNo = @EmployeeNo"

            ' Declare and initialize the parameter required by the command.
            Dim parID = New OleDb.OleDbParameter("@EmployeeNo", pID)

            ' Add the parameter to the command.
            command.Parameters.Add(parID)

            ' Execute the command and load the result set into the table.
            table.Load(command.ExecuteReader())

            ' Close the database connection.
            connection.Close()
            ' Check whether there was any results in the result set and load the result set's data into the input controls.
            If table.Rows.Count > 0 Then
                txtEmployeeNo.Text = table.Rows(0)("EmployeeNo").ToString()
                txtName.Text = table.Rows(0)("Name").ToString()
                txtSurname.Text = table.Rows(0)("Surname").ToString()
                TxtContactNo.Text = table.Rows(0)("Contact_No").ToString
            End If
        Catch ex As Exception
            ' Prompt the user with the exception.
            MessageBox.Show(ex.ToString())
        End Try
    End Sub

    Private Function GetEmployeeNo()
        ' Declare the Employee Number variable for use in this method.
        Dim EmployeeNo As Integer

        Try
            ' Declare the connection, command and table objects.
            Dim connection As New OleDb.OleDbConnection
            Dim command As New OleDb.OleDbCommand
            Dim table As New Data.DataTable

            ' Set the ConnectionString property and open the database connection.
            connection.ConnectionString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=E:\CP ISAT\Genisis\Database\GenisisFitnessClub.mdb"
            connection.Open()

            ' Set the Connection and CommandText properties of the command.
            command.Connection = connection
            command.CommandText = "SELECT TOP 1 EmployeeNo FROM Trainers ORDER BY EmployeeNo DESC"

            ' Execute the command and load the result set into the table.
            table.Load(command.ExecuteReader())

            ' Close the database connection.
            connection.Close()

            If table.Rows.Count > 0 Then ' Check whether there are any records in the result set.
                If Integer.TryParse(table(0)("EmployeeNo").ToString(), EmployeeNo) Then
                    ' Increment the Employee variable.
                    EmployeeNo = EmployeeNo + 1
                End If
                ' Else use the default starting EmployeeNo
            Else
                EmployeeNo = 0
            End If
        Catch ex As Exception
            ' Prompt the user with the exception.
            MessageBox.Show(ex.ToString())
        End Try

        ' Return the new EmployeeNo
        Return EmployeeNo
    End Function

    Private Sub EditTrainer_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ' Fetch the Trainer and display him/her in the DataGridView.
        GetTrainers()

        ' Clear the Mode.
        Mode = ""
    End Sub

    Private Sub grvStudents_SelectionChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
        ' Declare an Integer type variable used in this code block by the Integer.TryParse() method.
        Dim EmployeeNo As Integer

        If Not grvTrainers.CurrentRow Is Nothing Then ' Check whether the DataGridView has a valid CurrentRow.
            If Integer.TryParse(grvTrainers.CurrentRow.Cells("EmployeeNo").Value.ToString(), EmployeeNo) Then ' Use the Integer.TryParse() method to check the validity of the ID field.
                ' Fetch the Student's data and load it in the input controls.
                GetTrainer(EmployeeNo)
            End If
        End If
    End Sub

    Private Sub btnUpdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnUpdate.Click
        If grvTrainers.Rows.Count > 0 Then ' Check whether there are any rows available for updating.
            ' Disable the DataGridView control.
            grvTrainers.Enabled = False

            ' Disable the Update / Delete buttons whilst in update mode.
            btnUpdate.Enabled = False
            btnDelete.Enabled = False

            ' Enable the input controls for the update event.
            GroupBox1.Enabled = True

            ' Set the Mode of the form to UPDATE for future reference.
            Mode = "UPDATE"
        Else ' Else prompt the user that there no records available for updating.
            MessageBox.Show("There are no rows to update...")
        End If
    End Sub

    Private Sub btnSubmit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSubmit.Click
        ' Disable the input controls.
        GroupBox1.Enabled = False

        ' Enable the DataGridView.
        grvTrainers.Enabled = True

        ' Enable the Update / Delete buttons.
        btnUpdate.Enabled = True
        btnDelete.Enabled = True

        Select Case Mode
            ' If the mode is UPDATE, perform an existing record updating.
            Case "UPDATE"
                Try
                    ' Declare the connection and command objects.
                    Dim connection As New OleDb.OleDbConnection
                    Dim command As New OleDb.OleDbCommand

                    ' Set the ConnectionString property and open the database connection.
                    connection.ConnectionString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=E:\CP ISAT\Genisis\Database\GenisisFitnessClub.mdb"
                    connection.Open()

                    ' Set the Connection and CommandText properties of the command.
                    command.Connection = connection
                    command.CommandText = "UPDATE Trainers SET EmployeeNo = @EmployeeNo, Name = @Name, Surname = @Surname,Contact_No = @Contact_No WHERE EmployeeNo = @EmployeeNo"

                    ' Declare and initialize the parameters required by the command object.
                    Dim parEmployeeNo = New OleDb.OleDbParameter("@EmployeeNo", txtEmployeeNo.Text)
                    Dim parName = New OleDb.OleDbParameter("@Name", txtName.Text)
                    Dim parSurname = New OleDb.OleDbParameter("@Surname", txtSurname.Text)
                    Dim parContactNo = New OleDb.OleDbParameter("@Contact_No", TxtContactNo.Text)

                    ' Add the parameters to the command object.
                    command.Parameters.Add(parEmployeeNo)
                    command.Parameters.Add(parName)
                    command.Parameters.Add(parSurname)
                    command.Parameters.Add(parContactNo)

                    ' Execute the command.
                    command.ExecuteNonQuery()
                    ' Close the database connection.
                    connection.Close()

                    ' Update the DataGridView.
                    GetTrainers()
                Catch ex As Exception
                    ' Prompt the user with the exception.
                    MessageBox.Show(ex.ToString())
                End Try
            Case Else ' Else prompt the user that there is nothing to submit. 
                MessageBox.Show("Nothing to Submit...")
        End Select

        ' Clear the Mode.
        Mode = ""
    End Sub

    Private Sub btnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancel.Click
        ' Enable the DataGridView control.
        grvTrainers.Enabled = True

        ' Disable the input controls.
        GroupBox1.Enabled = False

        ' Enable the Update / Delete buttons.
        btnUpdate.Enabled = True
        btnDelete.Enabled = True

        ' Clear the Mode of the form.
        Mode = ""

        ' Check whether there are records in the DataGridView.
        If grvTrainers.Rows.Count > 0 Then
            ' Declare an Integer type variable used in this code block by the Integer.TryParse() method.
            Dim EmployeeNo As Integer
            ' Use the Integer.TryParse() method to check the validity of the ID field.
            If Integer.TryParse(grvTrainers.CurrentRow.Cells("EmployeeNo").Value.ToString(), EmployeeNo) Then
                ' Fetch the Student's data and load it in the input controls.
                GetTrainer(EmployeeNo)
            End If
        Else ' Else clear the input controls.
            txtEmployeeNo.Text = ""
            txtName.Text = ""
            txtSurname.Text = ""
            TxtContactNo.Text = ""
        End If
    End Sub

    Private Sub btnDelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDelete.Click
        If grvTrainers.Rows.Count > 0 Then ' Check whether there are any rows available for deletion.
            If MessageBox.Show("Are you sure you want to delete this student?", "Confirm delete", MessageBoxButtons.YesNo) = Windows.Forms.DialogResult.Yes Then ' Prompt the user to confirm deletion.
                ' On a Yes prompt, delete the record.
                Try
                    ' Declare the connection and command objects.
                    Dim connection As New OleDb.OleDbConnection
                    Dim command As New OleDb.OleDbCommand

                    ' Set the ConnectionString property and open the database connection.
                    connection.ConnectionString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=E:\CP ISAT\Genisis\Database\GenisisFitnessClub.mdb"
                    connection.Open()

                    ' Set the Connection and CommandText properties of the command.
                    command.Connection = connection
                    command.CommandText = "DELETE FROM Trainers WHERE EmployeeNo = @EmployeeNo"

                    ' Declare and initialize the parameter required for the command.
                    Dim parID = New OleDb.OleDbParameter("@EmployeeNo", grvTrainers.CurrentRow.Cells("EmployeeNo").Value)

                    ' Add the parameter to the command.
                    command.Parameters.Add(parID)

                    ' Execute the command.
                    command.ExecuteNonQuery()

                    ' Close the connection.
                    connection.Close()

                    ' Update the DataGridView control.
                    GetTrainers()
                Catch ex As Exception
                    ' Prompt the user with the exception.
                    MessageBox.Show(ex.ToString())
                End Try
            End If
        Else ' Else prompt the user that there are no records available for deletion.
            MessageBox.Show("There are no records to delete...")
        End If
    End Sub

    Private Sub grvTrainers_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles grvTrainers.CellDoubleClick
        'Fetch selected row
        Dim i As Integer
        i = grvTrainers.CurrentRow.Index
        txtName.Text = grvTrainers.Item(1, i).Value
        txtSurname.Text = grvTrainers.Item(2, i).Value
        txtEmployeeNo.Text = grvTrainers.Item(0, i).Value
        TxtContactNo.Text = grvTrainers.Item(3, i).Value
    End Sub

    Private Sub BtnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnClose.Click
        Me.Dispose()
    End Sub
End Class