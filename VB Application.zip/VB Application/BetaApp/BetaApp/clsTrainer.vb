﻿Public Class clsTrainer
    'Inherit from parent class
    Inherits clsPerson
    'Data Members
    Private TrainerClass As String
    Private Salary, Commission As Decimal
    Private DateHired As Date
    Private Name, Surname As String
    Private ContactNo As String
    Private EmployeeNo As String

    'Create Constuctor with parameters
    Public Sub New(ByVal _Name As String, ByVal _Surname As String, ByVal _ContactNo As String, ByVal _DateHired As Date, ByVal _EmployeeNo As String)
        Name = _Name
        Surname = _Surname
        ContactNo = _ContactNo
        EmployeeNo = _EmployeeNo
        DateHired = _DateHired
    End Sub
    Public Sub New()
        _Commission = Commission
    End Sub
 
    'create a constructor for salary which is dependednt on class
    Public Sub New(ByVal _Trainerclass As String, ByVal _salary As Decimal)
        TrainerClass = _Trainerclass
        Salary = _salary
    End Sub
    'Set properties
    Public Property _Surname() As String
        Get
            Return Surname
        End Get
        Set(ByVal value As String)
            Surname = value
        End Set
    End Property

    Public Property _Name() As String
        Get
            Return Name
        End Get
        Set(ByVal value As String)
            Name = value
        End Set
    End Property

    Public Property _ContactNo() As String
        Get
            Return ContactNo
        End Get
        Set(ByVal value As String)
            ContactNo = value
        End Set
    End Property

    Property _DateHired() As Date
        Get
            Return DateHired
        End Get
        Set(ByVal value As Date)
            DateHired = value
        End Set
    End Property

    Property _TrainerClass() As String
        Get
            Return TrainerClass
        End Get
        Set(ByVal value As String)
            TrainerClass = value
        End Set
    End Property

    Property _Salary() As Decimal
        Get
            Return Salary
        End Get
        Set(ByVal value As Decimal)
            Salary = value
        End Set
    End Property

    Public Property _Commission() As Decimal
        Get
            Return Commission
        End Get
        Set(ByVal value As Decimal)
            Commission = value
        End Set
    End Property

    Public Property _EmployeeNo() As String
        Get
            Return EmployeeNo
        End Get
        Set(ByVal value As String)
            EmployeeNo = value
        End Set
    End Property
   

End Class
