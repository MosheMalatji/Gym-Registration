﻿Public Class AddGymMember
    Dim Member As ClsMember
    Dim TrainerPool As String


    Private Sub DtpDOB_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DtpDOB.ValueChanged
        LblAge.Text = 0
        'Instantiate object
        Member = New ClsMember(LblAge.Text)
        'calculate  exact age of member
        Member._Age = Math.Floor(DateDiff(DateInterval.Month, DtpDOB.Value, System.DateTime.Now) / 12)
        LblAge.Text = Member._Age
    End Sub
    'exit button
    Private Sub BtnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnExit.Click
        'me.dispose clears all the controls when exit button is clicked
            Me.Dispose()
    End Sub
    'Function to validate input with one parameter
    Function Validataion(ByRef returnmsg As String) As Boolean
        'Declare a boolean variable to be used in represent validity of condition
        Dim validity As Boolean = False
        If String.IsNullOrEmpty(TxtName.Text) Or String.IsNullOrEmpty(TxtSurname.Text) Or String.IsNullOrEmpty(TxtIDNumber.Text) Or String.IsNullOrEmpty(TxtContactNo.Text) Then
            returnmsg = "Please fill in all fields"
        ElseIf String.IsNullOrEmpty(TxtHeight.Text) Or String.IsNullOrEmpty(Txtweight.Text) Or String.IsNullOrEmpty(TxtHRrest.Text) Then
            returnmsg = "Please fill in all fields"
        ElseIf IsNumeric(TxtName.Text) Then
            returnmsg = "Name cannot contain numeric values.Please enter your name again."
            TxtName.Clear()
            TxtName.Focus()
        ElseIf IsNumeric(TxtSurname.Text) Then
            returnmsg = "Surname cannot contain numeric values.Please type your surname again"
            TxtSurname.Clear()
            TxtSurname.Focus()
        ElseIf IsNumeric(TxtIDNumber.Text) = False Then
            returnmsg = "Id Number is invalid. Please check that you have not made any errors"
            TxtIDNumber.Focus()
        ElseIf TxtIDNumber.Text.Length = 13 = False Then
            returnmsg = "Id Number must be exactly 13 characters"
            TxtIDNumber.Focus()
        ElseIf cmbMembershipType.SelectedIndex = 0 Then
            returnmsg = "Please select a membership type"
            cmbMembershipType.Focus()
        ElseIf RadMale.Checked = False And RadFemale.Checked = False Then
            returnmsg = "Please pick a gender"
        ElseIf IsNumeric(Txtweight.Text) = False Then
            returnmsg = "Weight must be a numeric value"
            Txtweight.Focus()
        ElseIf Txtweight.Text < 30 Then
            returnmsg = "Members who weigh less than 30kgs are not physically able to join a gym "
        Else
            validity = True
        End If
        Return validity
    End Function
    'Displays additional info on HRmax usin tooltip
    Private Sub TxtHRmax_MouseHover(ByVal sender As System.Object, ByVal e As System.EventArgs)
        TtpInfo.SetToolTip(LblHRmax, " Members maximum heart beat per minute")
    End Sub
    'Displays additional information on hrest using a tooltip
    Private Sub TxtHRrest_MouseHover(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TxtHRrest.MouseHover
        TtpInfo.SetToolTip(TxtHRrest, "Members heart beat per minute at rest")
    End Sub

    Private Sub BtnSubmit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnSubmit.Click
        Dim msg As String = " "

        If Validataion(msg) = False Then
            MessageBox.Show(msg, "Invalid entry", MessageBoxButtons.OK, MessageBoxIcon.Information)
        Else
            Call SetMembershipTypeAndFee()
            lblFee.Text = Member._MemFee.ToString("C2")
            LblHRmax.Text = CalcluateHRmax().ToString("N2")
            LblVo2max.Text = CalculateV02max().ToString("N2")
            LblBMI.Text = CalculateBMI().ToString("N2")
            MessageBox.Show("Everything seems to be okay. Press Next to Assign a Trainer", "Valid Entry", MessageBoxButtons.OK, MessageBoxIcon.Information)
            BtnSave.Enabled = True
        End If
    End Sub

    Private Sub AddGymMember_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'clear interface
        TxtIDNumber.Clear()
        TxtName.Clear()
        TxtSurname.Clear()
        DtpDOB.Value = Today.Date
        RadFemale.Checked = False
        RadMale.Checked = False
        LblAge.Text = " "
        DtpDateJoined.Value = Today.Date
        TxtContactNo.Clear()
        'this is used instead of selected index = 0 and .resettext becuase it prevents the combox from repeating the array content
        cmbMembershipType.Items.Clear()
        lblFee.Text = " "
        Txtweight.Clear()
        TxtHeight.Clear()
        TxtHRrest.Clear()
        LblHRmax.Text = " "
        LblVo2max.Text = " "
        LblBMI.Text = " "
        Dim arrMembership() As String = {"Please Select a membership", "Basic", "Standard", "Premium"}
        Dim i As Integer
        For i = 0 To arrMembership.Length - 1
            cmbMembershipType.Items.Add(arrMembership(i))
            cmbMembershipType.SelectedIndex = 0
        Next
    End Sub

    Public Sub SetMembershipTypeAndFee()
        lblFee.Text = 0
        Member = New ClsMember(TxtName.Text, TxtSurname.Text, TxtContactNo.Text, cmbMembershipType.SelectedText, lblFee.Text)

        Select Case cmbMembershipType.SelectedIndex
            Case 1
                Member._MemType = "Basic"
                Member._MemFee = 250
                TrainerPool = "Class C"
            Case 2
                Member._MemType = "Standard"
                Member._MemFee = 375
                TrainerPool = "Class B"
            Case 3
                Member._MemType = "Premium"
                Member._MemFee = 500
                TrainerPool = "Class A"
        End Select
    End Sub

    Sub ClearControls()
        TxtIDNumber.Clear()
        TxtName.Clear()
        TxtSurname.Clear()
        DtpDOB.Value = Today.Date
        RadFemale.Checked = False
        RadMale.Checked = False
        LblAge.Text = " "
        DtpDateJoined.Value = Today.Date
        TxtContactNo.Clear()
        cmbMembershipType.SelectedIndex = 0
        lblFee.Text = " "
        Txtweight.Clear()
        TxtHeight.Clear()
        TxtHRrest.Clear()
        LblHRmax.Text = " "
        LblVo2max.Text = " "
        LblBMI.Text = " "
    End Sub

    Private Sub BtnClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnClear.Click
        Call ClearControls()
    End Sub

    Function CalculateV02max() As Decimal
        LblVo2max.Text = 0
        Member = New ClsMember(TxtHeight.Text, Txtweight.Text, TxtHRrest.Text, LblVo2max.Text, LblHRmax.Text)
        Member._HRest = TxtHRrest.Text
        Member._HRmax = LblHRmax.Text
        Member._VO2max = 15 * (Member._HRmax / Member._HRest)
        Return CDec(Member._VO2max)
    End Function

    Function CalcluateHRmax() As Decimal
        LblHRmax.Text = 0
        Member = New ClsMember(TxtHeight.Text, Txtweight.Text, TxtHRrest.Text, LblVo2max.Text, LblHRmax.Text)
        Member = New ClsMember(LblAge.Text)
        Member._HRmax = 205.8 - (0.685 * Member._Age)
        Return Member._HRmax
    End Function

    Function CalculateBMI() As Decimal
        Member = New ClsMember(TxtHeight.Text, Txtweight.Text, TxtHRrest.Text, LblVo2max.Text, LblHRmax.Text)
        Member = New ClsMember(LblAge.Text)
        Member._Weight = Txtweight.Text
        Member._Height = TxtHeight.Text
        Member._Age = LblAge.Text
        If RadMale.Checked = True Then
            Member._BMI = 0.5 * Member._Weight / (Member._Height / 100) ^ 2 + 11.5
        ElseIf RadFemale.Checked = True Then
            Member._BMI = CDec(0.5 * Member._Weight / (Member._Height / 100) ^ 2 + 0.03 * Member._Age + 11)
        Else
        End If

        Return Member._BMI
    End Function

    Sub SavePersonalnfoToDb()
        Dim command As New OleDb.OleDbCommand
        Dim connect As New OleDb.OleDbConnection
        Dim ParID As OleDb.OleDbParameter
        Dim ParName As OleDb.OleDbParameter
        Dim ParSurname As OleDb.OleDbParameter
        Dim ParNum As OleDb.OleDbParameter
        Dim parDOB As OleDb.OleDbParameter
        Dim ParGender As OleDb.OleDbParameter
        Dim ParJD As OleDb.OleDbParameter
        Dim ParType As OleDb.OleDbParameter
        Dim parFee As OleDb.OleDbParameter

        Dim sql As String
        Dim Provider As String
        Dim source As String
        Call SetMembershipTypeAndFee()
        If RadFemale.Checked = True Then
            Member._Gender = "Female"
        Else
            Member._Gender = "Male"
        End If
      
        Try
            sql = "INSERT INTO Member_Personal(IDNumber,Member_Name,Member_Surname,ContactNo,Date_Of_Birth,Gender,Join_Date,Membership_Type,Membership_Fee) VALUES(@ID,@Name,@Surname,@ContactNo,@DOB,@Gender,@JoinDate,@MemType,@MemFee) "
            Provider = "Provider=Microsoft.jet.Oledb.4.0; "
            source = "data source =C:\Users\Moshe\Documents\CP ISAT\Genisis\Database\GenisisFitnessClub.mdb"
            connect.ConnectionString = Provider & source
            command.Connection = connect
            connect.Open()
            command.CommandText = sql
            ParID = New OleDb.OleDbParameter("@ID", TxtIDNumber.Text)
            ParName = New OleDb.OleDbParameter("@Name", TxtName.Text)
            ParSurname = New OleDb.OleDbParameter("@Surname", TxtSurname.Text)
            ParNum = New OleDb.OleDbParameter("@ContactNo", TxtContactNo.Text)
            parDOB = New OleDb.OleDbParameter("@DOB", DtpDOB.Value.Date)
            ParGender = New OleDb.OleDbParameter("@Gender", Member._Gender)
            ParJD = New OleDb.OleDbParameter("@JoinDate", DtpDateJoined.Value.Date)
            ParType = New OleDb.OleDbParameter("@MemType", Member._MemType)
            parFee = New OleDb.OleDbParameter("@MemFee", Member._MemFee)

            command.Parameters.Add(ParID)
            command.Parameters.Add(ParName)
            command.Parameters.Add(ParSurname)
            command.Parameters.Add(ParNum)
            command.Parameters.Add(parDOB)
            command.Parameters.Add(ParGender)
            command.Parameters.Add(ParJD)
            command.Parameters.Add(parType)
            command.Parameters.Add(parFee)
            command.ExecuteNonQuery()

        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Sub SavePhysicalInfoToDb()
        Dim command As New OleDb.OleDbCommand
        Dim connect As New OleDb.OleDbConnection
        Dim Para1 As OleDb.OleDbParameter
        Dim Para2 As OleDb.OleDbParameter
        Dim Para3 As OleDb.OleDbParameter
        Dim Para4 As OleDb.OleDbParameter
        Dim Para5 As OleDb.OleDbParameter
        Dim Para6 As OleDb.OleDbParameter
        Dim Para7 As OleDb.OleDbParameter
        Dim Provider As String
        Dim source As String
        Dim sql As String

      
        Try
            Provider = "Provider=Microsoft.jet.Oledb.4.0; "
            source = "data source =C:\Users\Moshe\Documents\CP ISAT\Genisis\Database\GenisisFitnessClub.mdb"
            sql = "INSERT INTO Member_Physical(Member_ID,Height,Weight,HRrest,HRmax,VO2max,BMI) VALUES(@ID,@Height,@Weight,@HRrest,@HRmax,@VO2max,@BMI) "
            connect.ConnectionString = Provider & source
            command.Connection = connect

            connect.Open()
            command.CommandText = sql

            Para1 = New OleDb.OleDbParameter("@ID", TxtIDNumber.Text)
            Para2 = New OleDb.OleDbParameter("@Height", TxtHeight.Text)
            Para3 = New OleDb.OleDbParameter("@Weight", Txtweight.Text)
            Para4 = New OleDb.OleDbParameter("@HRrest", TxtHRrest.Text)
            Para5 = New OleDb.OleDbParameter("@HRmax", LblHRmax.Text)
            Para6 = New OleDb.OleDbParameter("@VO2max", LblVo2max.Text)
            Para7 = New OleDb.OleDbParameter("@BMI", LblBMI.Text)

            command.Parameters.Add(Para1)
            command.Parameters.Add(Para2)
            command.Parameters.Add(Para3)
            command.Parameters.Add(Para4)
            command.Parameters.Add(Para5)
            command.Parameters.Add(Para6)
            command.Parameters.Add(Para7)

            command.ExecuteNonQuery()
            connect.Close()
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try

    End Sub

    Private Sub BtnSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnSave.Click
        Call SavePersonalnfoToDb()
        Call SavePhysicalInfoToDb()
        Call SetMembershipTypeAndFee()
        Me.Hide()
        FrmAssignTrainer.ShowDialog()


    End Sub

    Sub ShowTrainerPool()
        Member = New ClsMember(TxtName.Text, TxtSurname.Text, TxtContactNo.Text, cmbMembershipType.SelectedText, lblFee.Text)
        Call SetMembershipTypeAndFee()
        Member._IDNumber = TxtIDNumber.Text
        FrmAssignTrainer.LblID.Text = Member._IDNumber
        FrmAssignTrainer.LblName.Text = Member._Name
        FrmAssignTrainer.LblSurname.Text = Member._Surname
        FrmAssignTrainer.LblMemType.Text = Member._MemType
        FrmAssignTrainer.LblTrainerClass.Text = TrainerPool
    End Sub

    Private Sub cmbMembershipType_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbMembershipType.SelectedIndexChanged
        Call SetMembershipTypeAndFee()
    End Sub

    
End Class