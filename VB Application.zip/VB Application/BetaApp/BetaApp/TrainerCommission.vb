﻿Imports System.Data.OleDb
Public Class TrainerCommission
    Dim Trainer As clsTrainer
    Sub GetNumOfTrainees()

        Dim strCnn As String = "Provider=Microsoft.jet.Oledb.4.0; data source =C:\Users\Moshe\Documents\CP ISAT\Genisis\Database\GenisisFitnessClub.mdb"
        Dim strSQL As String = "SELECT COUNT(*) FROM [Trainer_Trainee] WHERE [TrainerID]='" & LblID.Text & "' AND [Trainer_Class] = '" & LblClass.Text & "'"
        Dim cnn As New OleDbConnection(strCnn)
        Dim CMD As New OleDbCommand(strSQL, cnn)
        Dim DR As OleDbDataReader
        cnn.Open()
        DR = CMD.ExecuteReader()
        'Populate the reader
        While (DR.Read())
            LblTrainees.Text = DR(0).ToString()
        End While
        cnn.Close()
    End Sub

    Private Sub BtnSearch_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnSearch.Click

        Try
            ' Declare the connection, command and table objects.
            Dim connection As New OleDb.OleDbConnection
            Dim command As New OleDb.OleDbCommand
            Dim table As New Data.DataTable
            ' Set the ConnectionString property and open the database connection.
            connection.ConnectionString = "Provider=Microsoft.jet.Oledb.4.0; data source =E:\CP ISAT\Genisis\Database\GenisisFitnessClub.mdb"
            ' Set the Connection and CommandText properties of the command.
            command.Connection = connection
            'open Db
            connection.Open()
            'SQL query to look for Trainers where the employee number is the ompno entered in the text box
            command.CommandText = "SELECT * FROM Trainers WHERE EmployeeNo = @EmployeeNo"

            ' Declare and initialize the parameter required by the command.
            Dim parEmployeeNumber = New OleDb.OleDbParameter("@EmployeeNo", TxtSearch.Text)

            ' Add the parameter to the command.
            command.Parameters.Add(parEmployeeNumber)

            ' Execute the command and load the result set into the table.
            table.Load(command.ExecuteReader())


            If table.Rows.Count > 0 Then ' Check whether there was any results in the result set and load the result set's data into the input controls.
                LblID.Text = table.Rows(0)("EmployeeNo").ToString()
                lblName.Text = table.Rows(0)("Name").ToString()
                LblSurname.Text = table.Rows(0)("Surname").ToString()
                LblClass.Text = table.Rows(0)("Class").ToString()
                LblSalary.Text = table.Rows(0)("Salary").ToString()
                BtnCalculate.Enabled = True
            Else ' Else prompt the user that no Trainer was found and make all the display fields blank.
                LblID.Text = ""

                MessageBox.Show("Employee not found, please try again.")
            End If
            Call GetNumOfTrainees()
        Catch ex As Exception
            ' Prompt the user with the exception
            MessageBox.Show(ex.ToString())
        End Try

    End Sub

    Private Sub BtnCalculate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnCalculate.Click
        'Instantiate object
        Trainer = New clsTrainer(LblClass.Text, LblSalary.Text)
        Trainer._TrainerClass = LblClass.Text
        Trainer._Salary = LblSalary.Text
        If Trainer._TrainerClass = "Class A" Then
            Trainer._Commission = 25
        ElseIf Trainer._TrainerClass = "Class B" Then
            Trainer._Commission = 18.75
        ElseIf Trainer._TrainerClass = "Class C" Then
            Trainer._Commission = 12.5
        End If
        LblCommission.Text = (LblTrainees.Text * Trainer._Commission).ToString("C2")
        LblTotal.Text = (Trainer._Salary + (LblTrainees.Text * Trainer._Commission)).ToString("C2")
    End Sub

End Class