﻿Imports System.Data.OleDb
Public Class FrmLogin

    Private Sub BtnEnter_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnEnter.Click
       
        ' Declare the connection, command and reader objects.
        Dim connection As New OleDb.OleDbConnection
        Dim command As New OleDb.OleDbCommand
        'Dim dr As OleDbDataReader = command.ExecuteReader

        'create a connection to MS Access Db
        connection.ConnectionString = "Provider=Microsoft.jet.Oledb.4.0; data source =C:\Users\Moshe\Documents\CP ISAT\Genisis\Database\GenisisFitnessClub.mdb"
        'link connection to 
        command.Connection = connection
        'open Db
        connection.Open()
        'SQL query to look for username and password
        command.CommandText = "SELECT * FROM [Admin] WHERE [Username]='" & TxtUsername.Text & "' AND [Password] = '" & TxtPassword.Text & "'"
        Dim dr As OleDbDataReader = command.ExecuteReader
        ' variable if user exists
        Dim UserFound As Boolean = False
        'Variables will stor name and surname if user is Found
        Dim FirstName As String = ""
        Dim Surname As String = ""
        Dim b As String = ""
        'if found
        While dr.Read
            UserFound = True
            FirstName = dr("FirstName").ToString
            Surname = dr("Surname").ToString
        End While
        'checking the result
        If UserFound = True Then
            MainMenu.Show()
            Me.Hide()
            MainMenu.lbluser.Text = "Logged in as: " & " " & FirstName & " " & Surname
        Else
            MessageBox.Show("Password and username combination not recognised", "Invalid", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If

    End Sub

    Private Sub BtnClear_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnClear.Click
        TxtPassword.Clear()
        TxtUsername.Clear()
    End Sub

    Private Sub BtnExit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnExit.Click
        Me.Close()
    End Sub

End Class
