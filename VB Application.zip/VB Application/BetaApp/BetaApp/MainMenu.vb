﻿Public Class MainMenu
    Dim timeNow As Date = TimeOfDay
    Dim DateToday As Date = Today.Date.ToLongDateString

    Private Sub MainMenu_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        LblDate.Text = DateToday
        Lbltime.Text = timeNow
        LblVersion.Text = "Version : " & My.Application.Info.Version.Major.ToString & "." & _
        My.Application.Info.Version.Minor.ToString()
    End Sub

    Private Sub ExitToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ExitToolStripMenuItem.Click
        Me.Close()
        FrmLogin.Close()
    End Sub

    Private Sub AddTrainerToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AddTrainerToolStripMenuItem.Click
        AddTrainer.ShowDialog()
    End Sub

    Private Sub AddMemeberToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AddMemeberToolStripMenuItem.Click
        AddGymMember.ShowDialog()
    End Sub

    Private Sub ViewTrainersToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ViewTrainersToolStripMenuItem.Click
        TrainerCommission.ShowDialog()
    End Sub

    Private Sub ToolStripMenuItem3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ToolStripMenuItem3.Click
        AboutBox.ShowDialog()
    End Sub

    Private Sub EditTrainerInfoToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles EditTrainerInfoToolStripMenuItem.Click
        EditTrainer.ShowDialog()
    End Sub
    
    Private Sub EditPersonalInfoToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles EditPersonalInfoToolStripMenuItem.Click
        EditMember.ShowDialog()
    End Sub

    Private Sub EditPhysicalIndoToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles EditPhysicalIndoToolStripMenuItem.Click
        EditPhysicalInfo.ShowDialog()
    End Sub

    Private Sub SearchMemberToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SearchMemberToolStripMenuItem.Click
        SearchMember.ShowDialog()
    End Sub
End Class