﻿Public Class EditPhysicalInfo
    ' Declare the String variable to keep track of the state of the form. E.g. INSERT / UPDATE
    Dim Mode As String

    Public Sub GetMembers()
        Try
            ' Declare the connection, command and table objects.
            Dim connection As New OleDb.OleDbConnection
            Dim command As New OleDb.OleDbCommand
            Dim table As New Data.DataTable

            ' Initialize the ConnectionString and open the database connection.
            connection.ConnectionString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\Users\Moshe\Documents\CP ISAT\Genisis\Database\GenisisFitnessClub.mdb"
            connection.Open()

            ' Set the Connection and CommandText properties of the command.
            command.Connection = connection
            command.CommandText = "SELECT * FROM Member_Physical ORDER BY Member_ID"

            ' Execute the command and load the result set into the table.
            table.Load(command.ExecuteReader())

            ' Close the database connection.
            connection.Close()

            ' Set the table as the DataSource for the DataGridView.
            grvMembers.DataSource = table
        Catch ex As Exception
            ' Prompt the user with the exception.
            MessageBox.Show(ex.ToString())
        End Try
    End Sub

    Private Sub GetMember(ByVal pID As Integer)
        Try
            ' Declare the connection, command and table objects.
            Dim connection As New OleDb.OleDbConnection
            Dim command As New OleDb.OleDbCommand
            Dim table As New Data.DataTable

            ' Set the ConnectionString property and open the database connection.
            connection.ConnectionString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=E:\CP ISAT\Genisis\Database\GenisisFitnessClub.mdb"
            connection.Open()

            ' Set the Connection and CommandText properties of the command.
            command.Connection = connection
            command.CommandText = "SELECT * FROM Member_Physical WHERE Member_ID = @IDNumber"

            ' Declare and initialize the parameter required by the command.
            Dim parID = New OleDb.OleDbParameter("@IDNumber", pID)

            ' Add the parameter to the command.
            command.Parameters.Add(parID)

            ' Execute the command and load the result set into the table.
            table.Load(command.ExecuteReader())

            ' Close the database connection.
            connection.Close()

            If table.Rows.Count > 0 Then ' Check whether there was any results in the result set and load the result set's data into the input controls.
                txtID.Text = table.Rows(0)("Member_ID").ToString()
                TxtHeight.Text = table.Rows(0)("Height").ToString()
                TxtWeight.Text = table.Rows(0)("Weight").ToString()
                TxtHRrest.Text = table.Rows(0)("HRrest").ToString()
                TxtHRmax.Text = table.Rows(0)("HRmax").ToString()
                TxtBMI.Text = table.Rows(0)("V02max").ToString()
            End If
        Catch ex As Exception
            ' Prompt the user with the exception.
            MessageBox.Show(ex.ToString())
        End Try
    End Sub

    Private Sub EditMembers_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ' Fetch the lecturers and display it in the DataGridView.
        GetMembers()

        ' Clear the Mode.
        Mode = ""
    End Sub

    Private Sub btnUpdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnUpdate.Click
        If grvMembers.Rows.Count > 0 Then ' Check whether there are any rows available for updating.
            ' Disable the DataGridView control.
            grvMembers.Enabled = False

            ' Disable the Insert / Update / Delete buttons whilst in update mode.
            btnUpdate.Enabled = False
            btnDelete.Enabled = False

            ' Enable the input controls for the update event.
            GroupBox1.Enabled = True

            ' Set the Mode of the form to UPDATE for future reference.
            Mode = "UPDATE"
        Else ' Else prompt the user that there no records available for updating.
            MessageBox.Show("There are no rows to update...")
        End If
    End Sub

    Private Sub btnDelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDelete.Click
        If grvMembers.Rows.Count > 0 Then ' Check whether there are any rows available for deletion.
            If MessageBox.Show("Are you sure you want to delete this gym member?", "Confirm delete", MessageBoxButtons.YesNo) = Windows.Forms.DialogResult.Yes Then ' Prompt the user to confirm deletion.
                ' On a Yes prompt, delete the record.
                Try
                    ' Declare the connection and command objects.
                    Dim connection As New OleDb.OleDbConnection
                    Dim command As New OleDb.OleDbCommand

                    ' Set the ConnectionString property and open the database connection.
                    connection.ConnectionString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=E:\CP ISAT\Genisis\Database\GenisisFitnessClub.mdb"
                    connection.Open()

                    ' Set the Connection and CommandText properties of the command.
                    command.Connection = connection
                    'Delete the members personal info as well as their physical info
                    command.CommandText = "DELETE FROM Member_Personal WHERE IDNumber = @IDNumber"
                    command.CommandText = "DELETE FROM Member_Physical WHERE Member_ID = @IDNumber"


                    ' Declare and initialize the parameter required for the command.
                    Dim parID = New OleDb.OleDbParameter("@IDNumber", grvMembers.CurrentRow.Cells("Member_ID").Value)

                    ' Add the parameter to the command.
                    command.Parameters.Add(parID)

                    ' Execute the command.
                    command.ExecuteNonQuery()

                    ' Close the connection.
                    connection.Close()

                    ' Update the DataGridView control.
                    GetMembers()
                Catch ex As Exception
                    ' Prompt the user with the exception.
                    MessageBox.Show(ex.ToString())
                End Try
            End If
        Else ' Else prompt the user that there are no records available for deletion.
            MessageBox.Show("There are no records to delete...")
        End If
    End Sub

    Private Sub btnSubmit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSubmit.Click
        ' Disable the input controls.
        GroupBox1.Enabled = False

        ' Enable the DataGridView.
        grvMembers.Enabled = True

        ' Enable the Insert / Update / Delete buttons.
        btnUpdate.Enabled = True
        btnDelete.Enabled = True

        ' Test for the Mode of the form and perform the necessary actions accordingly.
        Select Case Mode
            Case "UPDATE" ' If the mode is UPDATE, perform an existing record updating.
                Try
                    ' Declare the connection and command objects.
                    Dim connection As New OleDb.OleDbConnection
                    Dim command As New OleDb.OleDbCommand

                    ' Set the ConnectionString property and open the database connection.
                    connection.ConnectionString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=E:\CP ISAT\Genisis\Database\GenisisFitnessClub.mdb"
                    connection.Open()

                    ' Set the Connection and CommandText properties of the command.
                    command.Connection = connection
                    command.CommandText = "UPDATE Member_Physical SET Member_ID=@IDNumber Height = @Height, Weight = @Weight,HRrest = @HRrest,HRmax = @HRmax,VO2max = @VO2max,BMI = @BMI WHERE IDNumber = @IDNumber"

                    ' Declare and initialize the parameters required by the command object.
                    Dim parID = New OleDb.OleDbParameter("@IDNumber", txtID.Text)
                    Dim parHeight = New OleDb.OleDbParameter("@Name", TxtHeight.Text)
                    Dim parWeight = New OleDb.OleDbParameter("@Surname", TxtWeight.Text)
                    Dim parHRrest = New OleDb.OleDbParameter("@HRrest", TxtHRrest.Text)
                    Dim parHRmax = New OleDb.OleDbParameter("@HRmax", TxtHRmax.Text)
                    Dim parVO2max = New OleDb.OleDbParameter("@VO2max", TxtVO2max.Text)
                    Dim parBMI = New OleDb.OleDbParameter("@BMI", TxtBMI.Text)

                    ' Add the parameters to the command object.
                    command.Parameters.Add(parID)
                    command.Parameters.Add(parWeight)
                    command.Parameters.Add(parHeight)
                    command.Parameters.Add(parHRrest)
                    command.Parameters.Add(parHRmax)
                    command.Parameters.Add(parVO2max)
                    command.Parameters.Add(parBMI)


                    ' Execute the command.
                    command.ExecuteNonQuery()

                    ' Close the database connection.
                    connection.Close()

                    ' Update the DataGridView.
                    GetMembers()
                Catch ex As Exception
                    ' Prompt the user with the exception.
                    MessageBox.Show(ex.ToString())
                End Try
            Case Else ' Else prompt the user that there is nothing to submit. This is only a failover mechanism and will rarely be used.
                MessageBox.Show("Nothing to Submit...")
        End Select

        ' Clear the Mode.
        Mode = ""
    End Sub

    Private Sub btnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancel.Click
        ' Enable the DataGridView control.
        grvMembers.Enabled = True

        ' Disable the input controls.
        GroupBox1.Enabled = False

        ' Enable the Insert / Update / Delete buttons.
        btnUpdate.Enabled = True
        btnDelete.Enabled = True

        ' Clear the Mode of the form.
        Mode = ""

        If grvMembers.Rows.Count > 0 Then ' Check whether there are records in the DataGridView.
            ' Declare an Integer type variable used in this code block by the Integer.TryParse() method.
            Dim ID As Integer

            If Integer.TryParse(grvMembers.CurrentRow.Cells("IDNumber").Value.ToString(), ID) Then ' Use the Integer.TryParse() method to check the validity of the ID field.
                ' Fetch the Members data and load it in the input controls.
                GetMember(ID)
            End If
        Else ' Else clear the input controls.
            txtID.Text = ""
            TxtHeight.Text = ""
            TxtWeight.Text = ""
            TxtHRrest.Text = " "
            TxtHRmax.Text = " "
            TxtVO2max.Text = " "
            TxtBMI.Text = " "
        End If
    End Sub

    Private Sub grvMembers_SelectionChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles grvMembers.SelectionChanged
        ' Declare an Integer type variable used in this code block by the Integer.TryParse() method.
        Dim IDNumber As Integer

        If Not grvMembers.CurrentRow Is Nothing Then ' Check whether the DataGridView has a valid CurrentRow.
            If Integer.TryParse(grvMembers.CurrentRow.Cells("Member_ID").Value.ToString(), IDNumber) Then ' Use the Integer.TryParse() method to check the validity of the ID field.
                ' Fetch the Lecturer's data and load it in the input controls.
                GetMember(IDNumber)
            End If
        End If
    End Sub

    Private Sub grvMembers_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles grvMembers.CellDoubleClick
        'Fetch selected row
        Dim i As Integer
        i = grvMembers.CurrentRow.Index
        txtID.Text = grvMembers.Item(0, i).Value
        TxtHeight.Text = grvMembers.Item(1, i).Value
        TxtWeight.Text = grvMembers.Item(2, i).Value
        TxtHRrest.Text = grvMembers.Item(3, i).Value
        TxtHRmax.Text = grvMembers.Item(4, i).Value
        TxtVO2max.Text = grvMembers.Item(5, i).Value
        TxtBMI.Text = grvMembers.Item(6, i).Value
    End Sub

End Class