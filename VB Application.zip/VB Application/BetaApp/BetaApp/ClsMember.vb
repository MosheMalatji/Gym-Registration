﻿Public Class ClsMember
    'Inherit from parent class
    Inherits clsPerson
    'Data Members
    Private Name, Surname As String
    Private IDNumber As Double
    Private JoinDate As Integer
    Private Age As Integer
    Private Height, Weight As Decimal
    Private Gender As String
    Private memType As String
    Private memFee As Decimal
    Private HRmax, HRest, Vo2max As Decimal
    Private BMI As Double

    'Create constructor with parameters for personal details
    Sub New(ByVal _Name As String, ByVal _Surname As String, ByVal _ContactNo As String, ByVal _memType As String, ByVal _memFee As Decimal)
        Name = _Name
        Surname = _Surname
        _ContactNo = _ContactNo
        memType = _memType
        memFee = _memFee
    End Sub
    Sub New(ByVal _Age As Integer)
        Age = _Age
    End Sub
    'Constructor with parameters
    Sub New(ByVal _height As Decimal, ByVal _gender As String, ByVal _Weight As Decimal, ByVal _HRmax As Decimal, ByVal _HRest As Decimal, ByVal _VO2max As Decimal, ByVal _Bmi As Double)
        Height = _height
        Weight = _Weight
        Gender = _gender
        HRest = _HRest
        HRmax = _HRmax
        Vo2max = _VO2max
        BMI = _BMI
    End Sub

    'Properties
    Public Property _Name() As String
        Get
            Return Name
        End Get
        Set(ByVal value As String)
            Name = value
        End Set
    End Property

    Public Property _Surname() As String
        Get
            Return Surname
        End Get
        Set(ByVal value As String)
            Surname = value
        End Set
    End Property

    Public Property _IDNumber() As Double
        Get
            Return IDNumber
        End Get
        Set(ByVal value As Double)
            IDNumber = value
        End Set
    End Property

    Public Property _JoinDate() As Integer
        Get
            Return JoinDate
        End Get
        Set(ByVal value As Integer)
            JoinDate = value
        End Set
    End Property

    Public Property _Age As Integer
        Get
            Return Age
        End Get
        Set(ByVal value As Integer)
            Age = value
        End Set
    End Property

    Public Property _Height As Decimal
        Get
            Return Height
        End Get
        Set(ByVal value As Decimal)
            Height = value
        End Set
    End Property

    Public Property _Weight As Decimal
        Get
            Return Weight
        End Get
        Set(ByVal value As Decimal)
            Weight = value
        End Set
    End Property

    Public Property _Gender As String
        Get
            Return Gender
        End Get
        Set(ByVal value As String)
            Gender = value
        End Set
    End Property

    Public Property _MemType As String
        Get
            Return memType
        End Get
        Set(ByVal value As String)
            memType = value
        End Set
    End Property

    Public Property _MemFee As Decimal
        Get
            Return memFee
        End Get
        Set(ByVal value As Decimal)
            memFee = value
        End Set
    End Property

    Public Property _HRmax As Decimal
        Get
            Return HRmax
        End Get
        Set(ByVal value As Decimal)
            HRmax = value
        End Set
    End Property

    Public Property _HRest As Decimal
        Get
            Return HRest
        End Get
        Set(ByVal value As Decimal)
            HRest = value
        End Set
    End Property

    Public Property _VO2max As Decimal
        Get
            Return Vo2max
        End Get
        Set(ByVal value As Decimal)
            Vo2max = value
        End Set
    End Property

    Public Property _BMI As Double
        Get
            Return BMI
        End Get
        Set(ByVal value As Double)
            BMI = value
        End Set
    End Property

End Class
